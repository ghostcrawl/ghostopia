from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.problem_details import ProblemDetails
    from .behavior_put_request_body import BehaviorPutRequestBody

class BehaviorRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /v1/selfhost/byo/behavior
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new BehaviorRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/v1/selfhost/byo/behavior", path_parameters)
    
    async def put(self,body: BehaviorPutRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[bytes]:
        """
        **Self-host deployments only.** Validate + persist a BYO behavior JSON, then report the sanitized count. Contract: ``{"human_actions": [ {kind,.},. ]}``. ``human_actions`` MUST be a list; it is passed through byo_behavior.sanitize_actions (allow-list + clamp). A non-empty input that sanitizes to an EMPTY plan (every action an invalid kind) → 422 invalid_behavior_json (nothing valid to apply). Success → write ~/.ghostcrawl/behavior.json + {reloaded, actions}.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: bytes
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_put_request_information(
            body, request_configuration
        )
        from .....models.problem_details import ProblemDetails

        error_mapping: dict[str, type[ParsableFactory]] = {
            "422": ProblemDetails,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        return await self.request_adapter.send_primitive_async(request_info, "bytes", error_mapping)
    
    def to_put_request_information(self,body: BehaviorPutRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        **Self-host deployments only.** Validate + persist a BYO behavior JSON, then report the sanitized count. Contract: ``{"human_actions": [ {kind,.},. ]}``. ``human_actions`` MUST be a list; it is passed through byo_behavior.sanitize_actions (allow-list + clamp). A non-empty input that sanitizes to an EMPTY plan (every action an invalid kind) → 422 invalid_behavior_json (nothing valid to apply). Success → write ~/.ghostcrawl/behavior.json + {reloaded, actions}.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PUT, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> BehaviorRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: BehaviorRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return BehaviorRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class BehaviorRequestBuilderPutRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

