from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ....models.batch_scrape_request import BatchScrapeRequest
    from ....models.problem_details import ProblemDetails

class BatchRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /v1/scrape/batch
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new BatchRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/v1/scrape/batch", path_parameters)
    
    async def post(self,body: BatchScrapeRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[bytes]:
        """
        concurrent URL scrape (max 20 URLs, max concurrency 10). 4-16 processes each URL with authentication. Each URL is processed (batch_identity_mode="persist" → one identity is created and reused for every URL). DoS mitigations (/02):
        param body: Request body for POST /v1/scrape/batch. Accepts 1–20 URLs and a concurrency cap 1–10. All other fields mirror the shared scrape params from ScrapeBody and are applied uniformly to every URL in the batch.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: bytes
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        from ....models.problem_details import ProblemDetails

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": ProblemDetails,
            "401": ProblemDetails,
            "402": ProblemDetails,
            "422": ProblemDetails,
            "429": ProblemDetails,
            "500": ProblemDetails,
            "503": ProblemDetails,
            "504": ProblemDetails,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        return await self.request_adapter.send_primitive_async(request_info, "bytes", error_mapping)
    
    def to_post_request_information(self,body: BatchScrapeRequest, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        concurrent URL scrape (max 20 URLs, max concurrency 10). 4-16 processes each URL with authentication. Each URL is processed (batch_identity_mode="persist" → one identity is created and reused for every URL). DoS mitigations (/02):
        param body: Request body for POST /v1/scrape/batch. Accepts 1–20 URLs and a concurrency cap 1–10. All other fields mirror the shared scrape params from ScrapeBody and are applied uniformly to every URL in the batch.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> BatchRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: BatchRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return BatchRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class BatchRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

