from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, ParseNodeHelper, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .scrape_result_status_member1 import ScrapeResult_statusMember1

@dataclass
class ScrapeResult_status(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ScrapeResult_statusMember1, str
    """
    # Composed type representation for type ScrapeResult_statusMember1
    scrape_result_status_member1: Optional[ScrapeResult_statusMember1] = None
    # Composed type representation for type str
    string: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ScrapeResult_status:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ScrapeResult_status
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        result = ScrapeResult_status()
        if string_value := parse_node.get_str_value():
            result.string = string_value
        else:
            from .scrape_result_status_member1 import ScrapeResult_statusMember1

            result.scrape_result_status_member1 = ScrapeResult_statusMember1()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .scrape_result_status_member1 import ScrapeResult_statusMember1

        if self.scrape_result_status_member1:
            return ParseNodeHelper.merge_deserializers_for_intersection_wrapper(self.scrape_result_status_member1)
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.string:
            writer.write_str_value(None, self.string)
        else:
            writer.write_object_value(None, self.scrape_result_status_member1)
    

