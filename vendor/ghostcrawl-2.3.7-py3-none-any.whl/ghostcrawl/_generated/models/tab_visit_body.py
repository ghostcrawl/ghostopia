from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .tab_visit_body_profile_id import TabVisitBody_profile_id
    from .tab_visit_body_session_id import TabVisitBody_session_id

@dataclass
class TabVisitBody(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The dwell_s property
    dwell_s: Optional[float] = 3
    # The profile_id property
    profile_id: Optional[TabVisitBody_profile_id] = None
    # The session_id property
    session_id: Optional[TabVisitBody_session_id] = None
    # The url property
    url: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TabVisitBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TabVisitBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TabVisitBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tab_visit_body_profile_id import TabVisitBody_profile_id
        from .tab_visit_body_session_id import TabVisitBody_session_id

        from .tab_visit_body_profile_id import TabVisitBody_profile_id
        from .tab_visit_body_session_id import TabVisitBody_session_id

        fields: dict[str, Callable[[Any], None]] = {
            "dwell_s": lambda n : setattr(self, 'dwell_s', n.get_float_value()),
            "profile_id": lambda n : setattr(self, 'profile_id', n.get_object_value(TabVisitBody_profile_id)),
            "session_id": lambda n : setattr(self, 'session_id', n.get_object_value(TabVisitBody_session_id)),
            "url": lambda n : setattr(self, 'url', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("dwell_s", self.dwell_s)
        writer.write_object_value("profile_id", self.profile_id)
        writer.write_object_value("session_id", self.session_id)
        writer.write_str_value("url", self.url)
        writer.write_additional_data_value(self.additional_data)
    

