"""ghostcrawl.human.timing — log-normal dwell + pre-click hesitation + Fitts pauses (AS-03, D-04).

The soul's "breath": how long a human lingers, hesitates, and pauses before moving. Every
generator here emits a **trusted-input** value — a ``{"kind": "dwell", "ms": int}`` dict or a
plain bounded millisecond int — and NEVER drives a browser timing/sleep API directly (the
``run_tasks.py`` anti-pattern D-04 forbids). The planner (198-08) sequences these into the plan.

Distributions (ENRICHED from the verified analog ``human_actions.py::_gaussian_delay`` — NOT
re-derived):
  * **Reading dwell** is **log-normal** (``exp(gauss(mu, sigma))`` seconds) off the per-instance
    ``profile["reading_dwell_lognorm"]`` — a heavy right tail is what real reading looks like.
  * **Micro / video / ad** dwells use their own log-normal / Gaussian bands (playbook 3.3).
  * **Pre-click hesitation** draws inside the profile's ``pre_click_hesitation_ms`` window
    (~0.5-2 s) — the "am I sure?" beat before a click.
  * **Fitts pause** grows with target distance (index of difficulty ``log2(D/W + 1)``).
  * Every output is clamped ``>= 0`` and ``<= _CEILING_MS`` so a pathological profile can neither
    go negative nor block forever. No fixed/periodic intervals — that is the #1 timing tell.
"""
from __future__ import annotations

import math
import os
import random

__all__ = ["dwell", "pre_click_hesitation", "fitts_pause",
           "soft_band", "beat", "dismiss_delay",
           "touch_hz", "touch_sample_gap", "touch_contact_hold", "touch_release_gap",
           "tap_dwell", "tap_dwell_jitter", "contact_radius_jitter",
           "pointer_hz", "pointer_sample_gap", "press_hold", "ease_out_exponent",
           "multi_touch_landing_gap"]

_CEILING_MS = 300_000  # 5 min — a sane hard ceiling on any single pause


def _ln_band(name: str, d_mu: float, d_sigma: float) -> tuple[float, float]:
    """A (mu, sigma) log-normal band with env overrides (``GHOSTCRAWL_DWELL_<NAME>_{MU,SIGMA}``),
    so the population can be re-fit to real Clarity time-on-page data without a redeploy (WS-2)."""
    try:
        mu = float(os.getenv(f"GHOSTCRAWL_DWELL_{name}_MU", str(d_mu)))
        sigma = float(os.getenv(f"GHOSTCRAWL_DWELL_{name}_SIGMA", str(d_sigma)))
    except ValueError:
        mu, sigma = d_mu, d_sigma
    return (mu, sigma)


# Per-kind dwell log-normal params (mu, sigma) over ln(seconds). "reading" (detail-page read) also
# falls back to profile["reading_dwell_lognorm"] when the caller passes a per-identity band.
# WS-2 (2026-09-27): "reading" was ~3 s (a GLANCE, not a read) and the walk used it for EVERY page,
# producing the tell-tale "3s,3s,3s,120s" profile. "reading" is now a real ~20 s detail read (heavy
# tail); "scan" is the short ~3 s glance kind for listing/reshuffle grids.
_DWELL_LOGNORM = {
    "scan": _ln_band("SCAN", 1.1, 0.5),        # ~3 s median — a glance at a listing / reshuffle grid
    "reading": _ln_band("READING", 3.0, 0.62), # ~20 s median detail-page read, heavy right tail
    "video": _ln_band("VIDEO", 2.5, 0.6),      # ~12 s median — watching a clip
    "ad": _ln_band("AD", 0.7, 0.5),            # ~2 s median — a glance at an ad slot
}
# Micro-pause: a Gaussian sub-second beat (cognitive / hand-reposition), in ms.
_MICRO_MEAN_MS = 250.0
_MICRO_SIGMA_MS = 80.0

# Fitts pre-movement pause: pause_ms ≈ base * ID, ID = log2(distance / W + 1).
_FITTS_W = 60.0            # effective target width (px)
_FITTS_BASE_MS = 150.0
_FITTS_NOISE_MS = 25.0


def _clamp_ms(value: float) -> int:
    """Clamp a millisecond value into ``[0, _CEILING_MS]`` and coerce to int."""
    return int(max(0.0, min(float(_CEILING_MS), value)))


def _lognormal_ms(mu: float, sigma: float, rng: random.Random) -> int:
    """Draw a log-normal duration in SECONDS from (mu, sigma) and return clamped ms."""
    seconds = math.exp(rng.gauss(mu, abs(sigma)))
    return _clamp_ms(seconds * 1000.0)


def dwell(kind: str, profile: dict, rng: random.Random | None = None) -> dict:
    """Draw a dwell pause for ``kind`` and return a ``{"kind": "dwell", "ms": int}`` dict.

    ``kind`` ∈ {"reading", "video", "ad", "micro"}. Reading uses the profile's per-instance
    ``reading_dwell_lognorm`` {mu, sigma}; the others use their playbook bands. Unknown kinds
    fall back to the micro band. ms is always clamped ``>= 0`` and ``<= _CEILING_MS``.
    """
    rng = rng or random.Random()

    if kind == "reading":
        params = profile.get("reading_dwell_lognorm") or {}
        mu = float(params.get("mu", _DWELL_LOGNORM["reading"][0]))
        sigma = float(params.get("sigma", _DWELL_LOGNORM["reading"][1]))
        ms = _lognormal_ms(mu, sigma, rng)
    elif kind in ("scan", "video", "ad"):
        mu, sigma = _DWELL_LOGNORM[kind]
        ms = _lognormal_ms(mu, sigma, rng)
    else:  # "micro" and any unknown kind
        # RIGHT-SKEWED micro-pause (log-normal), not a symmetric Gaussian: real inter-action beats
        # are right-skewed with a tail; a symmetric gauss understated the tail and (clamped at 0)
        # produced implausible near-zero beats. median ~0.22 s (≈ the old 250 ms center), heavy right tail.
        ms = _lognormal_ms(math.log(0.22), 0.35, rng)

    return {"kind": "dwell", "ms": ms}


def pre_click_hesitation(profile: dict, rng: random.Random | None = None) -> int:
    """The "am I sure?" beat before a click — an int ms inside the profile's ~0.5-2 s window.

    Draws inside ``profile["pre_click_hesitation_ms"]`` (a ``(lo, hi)`` tuple). A triangular
    draw biases toward the lower end (most clicks are quick; some deliberate) while keeping a
    real spread, so a sequence is never periodic.
    """
    rng = rng or random.Random()
    window = profile.get("pre_click_hesitation_ms", (500.0, 2000.0))
    try:
        lo, hi = float(window[0]), float(window[1])
    except (TypeError, ValueError, IndexError):
        lo, hi = 500.0, 2000.0
    if hi < lo:
        lo, hi = hi, lo
    # Triangular mode near the low end — quick clicks common, deliberate ones the tail. BUT a hard
    # cutoff at `hi` (2 s) truncates the real human tail: decision+movement latency is log-normal with
    # an occasional deliberate 3-5 s "hmm". ~6% of clicks draw from that long right tail instead, so
    # the cohort's pre-click distribution isn't walled at a round 2 s (a detectable aggregate edge).
    if rng.random() < 0.06:
        return _clamp_ms(min(5500.0, lo + math.exp(rng.gauss(math.log(hi), 0.5))))
    mode = lo + (hi - lo) * 0.35
    return _clamp_ms(rng.triangular(lo, hi, mode))


def fitts_pause(distance: float, profile: dict, rng: random.Random | None = None) -> int:
    """A pre-movement pause that grows with target distance (Fitts index of difficulty).

    ``pause ≈ base * log2(distance / W + 1)`` with Gaussian noise, scaled by the profile's
    ``mouse_speed_factor`` (a slower human pauses longer). Clamped to ``[0, _CEILING_MS]``.
    """
    rng = rng or random.Random()
    speed = float(profile.get("mouse_speed_factor", 1.0))
    idx = math.log2(max(0.0, float(distance)) / _FITTS_W + 1.0)
    base = _FITTS_BASE_MS * idx * speed + rng.gauss(0.0, _FITTS_NOISE_MS)
    return _clamp_ms(base)


# =========================================================================================
# Soft-edged reaction beats (2026-10-04). A `uniform(a, b)` pause is plausible PER DRAW but is a
# strong AGGREGATE tell: over thousands of sessions it renders as a flat histogram with hard
# vertical edges at exactly `a` and `b`. Real human notice→decide→act latency is right-skewed
# (log-normal / ex-Gaussian), has mass in the interior, and has NO hard edges in either direction.
# These two helpers are the shared replacement for every "human notices X and reacts" beat, so
# both harnesses get the same shape from ONE source (no fork — operator directive 2026-09-26).
# =========================================================================================

# Per-draw band jitter: the band ENDPOINTS are themselves drawn, so the cohort histogram has no
# vertical wall anywhere ("never a static number, never MIN==MAX, draw the band itself").
_BAND_JITTER = 0.14


def soft_band(lo: float, hi: float, rng: random.Random | None = None) -> tuple[float, float]:
    """Jitter a nominal ``(lo, hi)`` band by ±14% per draw → the band is never the same twice.

    Keeps ``lo < hi`` and ``lo >= 0``. Used by :func:`beat` / :func:`dismiss_delay` so the
    aggregate support is smeared instead of terminating on a round constant.
    """
    rng = rng or random.Random()
    j_lo = lo * (1.0 + rng.uniform(-_BAND_JITTER, _BAND_JITTER))
    j_hi = hi * (1.0 + rng.uniform(-_BAND_JITTER, _BAND_JITTER))
    lo2, hi2 = max(0.0, min(j_lo, j_hi)), max(j_lo, j_hi)
    if hi2 <= lo2:
        hi2 = lo2 + 1e-3
    return (lo2, hi2)


def beat(lo: float, hi: float, rng: random.Random | None = None, *,
         centre: float = 0.42, tail_p: float = 0.07, tail_mult: float = 2.2) -> float:
    """A human reaction beat in SECONDS over a soft-edged, interior-clustered distribution.

    Shape (what a real reaction latency looks like, not a dice roll):
      * the nominal band is jittered per draw (:func:`soft_band`) → no hard aggregate edges;
      * the body is a **triangular** draw with its mode at ``centre`` of the band (default 42%,
        i.e. clustered in the interior, slightly early — the "practiced" side);
      * ``tail_p`` of draws instead come from a **log-normal tail** reaching up to
        ``tail_mult x hi`` — the distracted human who takes noticeably longer.
    Always ``> 0`` with sub-second decimal resolution; never a fixed cadence.
    """
    rng = rng or random.Random()
    lo2, hi2 = soft_band(lo, hi, rng)
    if rng.random() < max(0.0, tail_p):
        # Long right tail: log-normal around the band top, capped at tail_mult x hi.
        return float(min(hi2 * max(1.0, tail_mult),
                         lo2 + math.exp(rng.gauss(math.log(max(1e-3, hi2 - lo2)), 0.45))))
    mode = lo2 + (hi2 - lo2) * max(0.0, min(1.0, centre))
    return float(rng.triangular(lo2, hi2, mode))


def dismiss_delay(rng: random.Random | None = None, *, kind: str = "popunder") -> float:
    """Seconds a human takes to NOTICE and DISMISS an unexpected window/overlay.

    The operator-specified band is ~1-3 s with the mass in the interior, and the realistic shape
    is **bimodal**: a practiced "ugh, not again" reflex close, and a slower "wait, what is this?"
    read-then-close. Both components are soft-edged :func:`beat` draws, so the mixture has no
    vertical wall and a genuine long tail (a distracted user can take 6-8 s).

    ``kind``:
      * ``popunder`` — a whole surprise TAB/WINDOW: must be seen, focused, and closed. Never
        sub-second: the window has to render and reach the eye first (floor ~0.9 s).
      * ``overlay``  — an in-page modal/vignette/sticky whose X is already on screen; a shade
        faster, same shape.
      * ``glance``   — the curious minority who actually READS the surprise surface first.
    """
    rng = rng or random.Random()
    if kind == "glance":
        return beat(2.6, 7.2, rng, centre=0.38, tail_p=0.10, tail_mult=1.8)
    if kind == "overlay":
        # Reflex close (~72%) vs. "what is this?" (~28%).
        if rng.random() < 0.72:
            return beat(0.75, 2.3, rng, centre=0.40)
        return beat(1.8, 4.2, rng, centre=0.35, tail_p=0.09)
    # popunder (default): the operator band. Reflex ~65% in 1.0-2.4 s, deliberate ~35% in
    # 1.8-3.4 s → the mixture's mass sits ~1-3 s, median ~1.8 s, with a soft tail past 3 s.
    if rng.random() < 0.65:
        return beat(1.0, 2.4, rng, centre=0.44)
    return beat(1.8, 3.4, rng, centre=0.36, tail_p=0.08, tail_mult=2.4)


# =========================================================================================
# TOUCH pacing (2026-10-04, R-4/R-5). A real phone's ``touchmove`` stream is NOT a uniform
# random dribble — it is emitted by a DIGITIZER sampling at a fixed device rate (60 / 90 / 120 /
# 144 Hz), so consecutive inter-event gaps cluster tightly around ONE per-device period with small
# dispatch jitter, plus the occasional coalesced/dropped frame at ~2x the period. Both touch paths
# (the raw-CDP relay branch and the worker-side op replay) previously drew every gap INDEPENDENTLY
# from a flat ``uniform(8, 25) ms`` rectangle — which, aggregated over the ~38% mobile share of the
# fleet, is a histogram no real device produces (flat, hard-walled, and with no per-gesture
# correlation between successive samples). These primitives are the shared replacement: ONE device
# rate per session, a soft per-sample gap, and human (not device) hold/release beats.
# =========================================================================================

# Real-device refresh/digitizer population (phones + tablets in the fleet's claim mix). Weights are
# population shares, not a uniform pick: 60 Hz is still the plurality, 120 Hz is the modern flagship
# tier, 90 Hz a mid-tier minority, 144 Hz a thin gaming-phone tail.
_TOUCH_HZ_POP: tuple[tuple[float, float], ...] = (
    (60.0, 0.44), (90.0, 0.14), (120.0, 0.38), (144.0, 0.04),
)
_TOUCH_SAMPLE_JITTER = 0.11   # per-sample dispatch jitter around the device period (sigma)
_TOUCH_COALESCE_P = 0.035     # a frame the compositor coalesced/dropped -> ~2x period
_TOUCH_GAP_FLOOR = 0.35       # never below this fraction of the period (two samples never collide)


def touch_hz(rng: random.Random | None = None) -> float:
    """Draw ONE device touch-sampling rate (Hz) from the real-device population.

    Called once per SESSION (a person does not swap phones mid-visit), so every gesture in that
    session is paced by the same digitizer — which is what makes the inter-event gaps correlate
    the way a real device's do.
    """
    rng = rng or random.Random()
    roll = rng.random()
    acc = 0.0
    for hz, share in _TOUCH_HZ_POP:
        acc += share
        if roll < acc:
            return hz
    return _TOUCH_HZ_POP[0][0]


def touch_sample_gap(hz: float, rng: random.Random | None = None) -> float:
    """Seconds between two consecutive ``touchmove`` samples on a ``hz``-rate digitizer.

    ``period * (1 + N(0, 0.11))`` with a ~3.5% coalesced-frame draw at ~2x the period, floored at
    0.35x the period. Soft-edged in both directions and tightly clustered — the real shape.
    """
    rng = rng or random.Random()
    try:
        period = 1.0 / max(1.0, float(hz))
    except (TypeError, ValueError):
        period = 1.0 / 60.0
    if rng.random() < _TOUCH_COALESCE_P:
        return period * (2.0 + abs(rng.gauss(0.0, 0.3)))
    return max(period * _TOUCH_GAP_FLOOR, period * (1.0 + rng.gauss(0.0, _TOUCH_SAMPLE_JITTER)))


def touch_contact_hold(rng: random.Random | None = None) -> float:
    """Seconds the finger RESTS on the glass after landing, before the first move (human beat)."""
    return beat(0.012, 0.038, rng, centre=0.40, tail_p=0.06, tail_mult=2.0)


def touch_release_gap(rng: random.Random | None = None) -> float:
    """Seconds between the LAST ``touchmove`` and the lift (human beat, not a device period)."""
    return beat(0.012, 0.048, rng, centre=0.38, tail_p=0.07, tail_mult=2.2)


def multi_touch_landing_gap(rng: random.Random | None = None) -> float:
    """Seconds between the FIRST and SECOND finger landing in a multi-touch gesture (R-7).

    Two fingers of one hand never contact the glass on the same digitizer frame. A pinch/two-finger
    gesture that reports both contacts with one identical ``touchstart`` timestamp is a synthetic
    tell that needs no statistics to see: the page reads
    ``e.touches[0].timeStamp == e.touches[1].timeStamp`` and, more decisively, sees ONE
    ``touchstart`` carrying two contacts where a real hand always fires TWO (the second one's
    ``touches`` list carrying both). Measured human spread is ~20-120 ms with a right tail (the
    thumb usually anchors first, the index follows).
    """
    return beat(0.020, 0.120, rng, centre=0.38, tail_p=0.08, tail_mult=2.0)


def tap_dwell(rng: random.Random | None = None) -> float:
    """Seconds a TAP presses the glass before lifting (used when the mask carries no dwell_ms)."""
    return beat(0.055, 0.135, rng, centre=0.40, tail_p=0.06, tail_mult=2.0)


def tap_dwell_jitter(nominal_s: float, rng: random.Random | None = None) -> float:
    """Jitter the identity's NOMINAL tap dwell per tap (R-4, 2026-10-04).

    The identity mask carries ONE ``dwell_ms`` per identity, and every tap of a session was
    dispatched with that exact value — measured: **1 distinct dwell across 40 taps**, i.e. the
    DOM-visible ``touchend.timeStamp - touchstart.timeStamp`` was byte-identical on every tap a
    soul ever made. No finger does that. The mask value is the person's CENTRAL tendency; each
    individual press varies log-normally around it (positive by construction, right-skewed — the
    occasional long press, never a negative or zero dwell, and no hard wall in either direction).
    """
    rng = rng or random.Random()
    try:
        nominal = float(nominal_s)
    except (TypeError, ValueError):
        nominal = 0.0
    if nominal <= 0.0:
        return tap_dwell(rng)
    # sigma 0.26 in log space -> ~68% within x0.77..x1.30 of the nominal, a real long-press tail.
    return float(max(0.012, nominal * math.exp(rng.gauss(0.0, 0.26))))


def contact_radius_jitter(nominal_px: float, rng: random.Random | None = None) -> float:
    """Jitter ONE contact-ellipse radius (px) around the identity's nominal fingertip size.

    A real digitizer measures the contact patch per touch, so ``Touch.radiusX``/``radiusY`` vary
    press to press (and differ from each other). The mask's single radius was stamped on EVERY
    point of every tap with radiusX == radiusY exactly — a constant pair no hardware reports.
    Only the GEOMETRY is jittered: ``force`` and ``rotationAngle`` are left exactly as the mask
    delivers them, because those two ARE platform constants on the claimed devices (iOS Safari
    without 3D Touch reports force 0.0 and rotationAngle 0.0 on every touch — jittering them
    would be the inverse tell).
    """
    rng = rng or random.Random()
    try:
        nominal = float(nominal_px)
    except (TypeError, ValueError):
        return 0.0
    if nominal <= 0.0:
        return nominal
    return float(max(1.0, nominal * (1.0 + rng.gauss(0.0, 0.085))))


# -----------------------------------------------------------------------------------------
# POINTER report rate (R-4/R-5, 2026-10-04). Exactly the digitizer argument, for the mouse:
# ``trajectory()`` stamped every move with ``dt_ms = max(2.0, gauss(14, 4.9))`` and NO profile ever
# set ``move_point_ms`` — measured over 5,000 drawn profiles: **1 distinct value (14.0) fleet-wide**,
# i.e. every soul's modal inter-``mousemove`` interval was the same ~71 Hz, and 0.68% of all moves
# landed on EXACTLY 2.00 ms (the hard floor). Real pointing hardware reports at 60/100/125/144 Hz
# depending on the device, so the modal interval is a per-PERSON constant drawn from a population.
# Capped at 144 Hz on purpose: above the compositor's frame rate the extra samples are coalesced
# and unobservable in the page, so claiming 1 kHz would only cost dispatches.
# -----------------------------------------------------------------------------------------
_POINTER_HZ_POP: tuple[tuple[float, float], ...] = (
    (60.0, 0.22), (72.0, 0.10), (100.0, 0.22), (125.0, 0.38), (144.0, 0.08),
)


def pointer_hz(rng: random.Random | None = None) -> float:
    """Draw ONE pointer report rate (Hz) per SESSION from the real-device population."""
    rng = rng or random.Random()
    roll = rng.random()
    acc = 0.0
    for hz, share in _POINTER_HZ_POP:
        acc += share
        if roll < acc:
            return hz
    return _POINTER_HZ_POP[-1][0]


def pointer_sample_gap(hz: float, rng: random.Random | None = None) -> float:
    """Seconds between two consecutive ``mousemove`` samples on a ``hz``-rate pointer.

    Log-normal around the device period: positive by construction (no ``max(floor, ...)`` wall),
    right-skewed the way a real OS input queue is (the occasional late/merged report), and tightly
    clustered around ONE per-session period so successive gaps CORRELATE as hardware's do.
    """
    rng = rng or random.Random()
    try:
        period = 1.0 / max(1.0, float(hz))
    except (TypeError, ValueError):
        period = 1.0 / 100.0
    return float(period * math.exp(rng.gauss(0.0, 0.30)))


def press_hold(rng: random.Random | None = None, *, mean_ms: float = 92.0,
               sigma_ms: float = 25.0) -> float:
    """Seconds a mouse button stays DOWN on a click (``mousedown``→``mouseup``).

    Log-normal around the profile's ``click_hold_mean_ms`` so the DOM-visible press duration is
    right-skewed with no hard edge (the worker path used a flat ``uniform(40, 130) ms`` box with
    walls on exactly 0.040 and 0.130).
    """
    rng = rng or random.Random()
    try:
        mean = max(8.0, float(mean_ms))
        sigma = max(1.0, float(sigma_ms))
    except (TypeError, ValueError):
        mean, sigma = 92.0, 25.0
    # Match the requested mean/sigma in LOG space (method of moments) so the profile knobs still
    # mean what they say while the shape gains its tail.
    var = (sigma / mean) ** 2
    mu = math.log(mean / math.sqrt(1.0 + var)) - math.log(1000.0)
    sg = math.sqrt(math.log(1.0 + var))
    return float(max(0.008, math.exp(rng.gauss(mu, sg))))


def ease_out_exponent(rng: random.Random | None = None) -> float:
    """Draw the velocity-DECAY exponent of one flick/drag (``f(t) = 1 - (1-t)**k``).

    ``device.swipe`` used a literal ``k = 2.0`` for every gesture in the fleet — measured over
    20,000 swipes the fitted exponent was a delta at 2.00 (p1 1.83 / p99 2.22, and that spread
    came only from the ±5 px position jitter). A real touch stream is a MIXTURE: a hard flick
    decelerates sharply (k ~ 1.8-3.4), a deliberate drag-scroll is nearly linear (k ~ 1.0-1.5),
    and the same person does both. Returned per GESTURE, never per session.
    """
    rng = rng or random.Random()
    if rng.random() < 0.28:
        # Deliberate drag: the finger keeps pace with the content; almost constant velocity.
        return beat(1.0, 1.5, rng, centre=0.42, tail_p=0.06, tail_mult=1.35)
    # Flick: launch fast, decay into the release.
    return beat(1.65, 3.2, rng, centre=0.40, tail_p=0.08, tail_mult=1.3)
