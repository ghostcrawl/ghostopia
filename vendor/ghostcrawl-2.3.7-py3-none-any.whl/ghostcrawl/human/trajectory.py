"""ghostcrawl.human.trajectory — neuromotor mouse path → move-dict stream (AS-01, D-04).

Generates a human-realistic pointer trajectory as a **trusted-input point stream** for the
GhostCrawl job plan: a ``list[{"kind": "move", "x": int, "y": int}]``. It NEVER drives a browser
pointer API directly — that direct-execution style is the ``run_tasks.py`` anti-pattern D-04
forbids. The downstream planner (198-08) hands these dicts to the session, where
``sanitize_actions`` clamps them at the trust boundary.

Physics (ENRICHED from the verified analog ``human_input.py`` — NOT re-derived):
  * PRIMARY path = a first-party **WindMouse** force loop (gravity toward target + smoothly
    varying wind + velocity damping), ported from ben.land's ~40-line writeup. NO ``windmouse``
    PyPI package is installed (supply-chain slop risk, RESEARCH A4 / threat T-198-08).
  * FINAL approach = a **3–12% overshoot past the target then an ease-out settle** back onto it
    (the analog's two-phase move, lines 243-271).
  * Gaussian jitter (``profile["jitter_px"]``) on interior points; step cadence scaled by
    ``profile["mouse_speed_factor"]``; Fitts point count clamped to ``[6, 50]``.
"""
from __future__ import annotations

import math
import random

import numpy as np

__all__ = ["trajectory"]

_SQRT3 = math.sqrt(3.0)
_SQRT5 = math.sqrt(5.0)

# WindMouse tuning (ben.land defaults): G gravity, W wind, M max-step, D wind-change distance.
_WM_G = 9.0
_WM_W = 3.0
_WM_M = 15.0
_WM_D = 12.0
_WM_MAX_ITERS = 5000  # hard cap so a degenerate force state can never spin forever


def _wm_params(profile: dict) -> tuple[float, float, float, float]:
    """Per-session WindMouse force constants (G/W/M/D), each bounded to ±15% of the ben.land default.

    Derived DETERMINISTICALLY from the profile's own per-session draw (speed/jitter) so a given
    identity keeps ONE stable neuromotor signature across all its moves, but different identities use
    different force fields. Explicit ``profile["wm_*"]`` overrides win if a caller pins them."""
    sp = float(profile.get("mouse_speed_factor", 1.0))
    jt = float(profile.get("jitter_px", 1.25))
    # Four decorrelated fractional parts in [0,1) from the two stable session values.
    f = ((sp * 7.31) % 1.0, (jt * 5.17) % 1.0, (sp * jt * 3.70 + 0.13) % 1.0, (sp + jt * 2.11) % 1.0)
    base = (_WM_G, _WM_W, _WM_M, _WM_D)
    keys = ("wm_g", "wm_w", "wm_m", "wm_d")
    out = []
    for k, b, fr in zip(keys, base, f):
        v = profile.get(k)
        out.append(float(v) if v is not None else b * (0.85 + 0.30 * fr))
    return out[0], out[1], out[2], out[3]


def _ease_in_out_cubic(t: float) -> float:
    """Cubic ease-in-out (BeCAPTCHA neuromotor velocity): slow → fast → slow."""
    if t < 0.5:
        return 4.0 * t * t * t
    return 1.0 - (-2.0 * t + 2.0) ** 3 / 2.0


def _ease_out_quad(t: float) -> float:
    """Quadratic ease-out: a decelerating approach (fine-correction settle)."""
    return 1.0 - (1.0 - t) * (1.0 - t)


def _fitts_points(distance: float, speed_factor: float = 1.0) -> int:
    """Fitts's-Law point count: MT ∝ log2(D/W + 1); clamped to [6, 50] (analog lines 169-180)."""
    if distance < 1.0:
        return 6
    pts = int(8 + 6 * math.log2(distance / 20.0 + 1.0))
    pts = int(pts * speed_factor)
    return max(6, min(50, pts))


def _wind_mouse(
    x0: float, y0: float, x1: float, y1: float, rng: random.Random,
    *, g: float = _WM_G, w: float = _WM_W, m: float = _WM_M, d: float = _WM_D,
) -> list[tuple[float, float]]:
    """First-party WindMouse force integrator (gravity + wind + damping).

    Ported from ben.land's algorithm; uses the caller's ``rng`` (not the global module state)
    so a fixed seed reproduces the identical path. Returns a dense list of float points from
    the start to the target.
    """
    cx, cy = x0, y0
    vx = vy = wx = wy = 0.0
    m_cur = m
    pts: list[tuple[float, float]] = [(cx, cy)]
    iters = 0
    dist = math.hypot(x1 - cx, y1 - cy)
    while dist >= 1.0 and iters < _WM_MAX_ITERS:
        iters += 1
        w_mag = min(w, dist)
        if dist >= d:
            wx = wx / _SQRT3 + (2.0 * rng.random() - 1.0) * w_mag / _SQRT5
            wy = wy / _SQRT3 + (2.0 * rng.random() - 1.0) * w_mag / _SQRT5
        else:
            wx /= _SQRT3
            wy /= _SQRT3
            if m_cur < 3.0:
                m_cur = rng.random() * 3.0 + 3.0
            else:
                m_cur /= _SQRT5
        vx += wx + g * (x1 - cx) / dist
        vy += wy + g * (y1 - cy) / dist
        v_mag = math.hypot(vx, vy)
        if v_mag > m_cur:
            v_clip = m_cur / 2.0 + rng.random() * m_cur / 2.0
            vx = (vx / v_mag) * v_clip
            vy = (vy / v_mag) * v_clip
        cx += vx
        cy += vy
        pts.append((cx, cy))
        dist = math.hypot(x1 - cx, y1 - cy)
    pts.append((x1, y1))
    return pts


def _resample_eased(dense: list[tuple[float, float]], n: int) -> list[tuple[float, float]]:
    """Pick ``n`` points off a dense path with ease-in-out parameter spacing.

    Eased (non-uniform) index mapping clusters samples at the ends and spreads them through the
    cruise — reproducing the accelerate/cruise/decelerate velocity envelope (so successive step
    distances vary). Endpoints are always preserved.
    """
    if n <= 1 or len(dense) <= 1:
        return [dense[0], dense[-1]]
    last = len(dense) - 1
    out: list[tuple[float, float]] = []
    for i in range(n):
        t = _ease_in_out_cubic(i / (n - 1))
        idx = int(round(t * last))
        out.append(dense[idx])
    return out


def _ease_out_settle(
    ox: float, oy: float, tx: float, ty: float, n: int, rng: random.Random,
) -> list[tuple[float, float]]:
    """Decelerating fine-correction from the overshoot point back onto the target."""
    if n <= 1:
        return [(tx, ty)]
    out: list[tuple[float, float]] = []
    for i in range(1, n + 1):
        t = _ease_out_quad(i / n)
        out.append((ox + (tx - ox) * t, oy + (ty - oy) * t))
    out[-1] = (tx, ty)
    return out


def trajectory(
    start: tuple[float, float],
    end: tuple[float, float],
    profile: dict,
    rng: random.Random | None = None,
) -> list[dict]:
    """Build a curved, jittered, overshoot-settling mouse path as move-dicts.

    Args:
        start: (x0, y0) origin in viewport coords.
        end:   (x1, y1) target in viewport coords.
        profile: a profile from ``soul.profiles`` — reads ``jitter_px``, ``mouse_speed_factor``,
                 ``overshoot_threshold_px``.
        rng: deterministic RNG; same seed reproduces the identical path.

    Returns:
        ``list[{"kind": "move", "x": int, "y": int}]`` — first point == ``start``, last == ``end``.
    """
    rng = rng or random.Random()
    x0, y0 = float(start[0]), float(start[1])
    x1, y1 = float(end[0]), float(end[1])
    distance = math.hypot(x1 - x0, y1 - y0)

    speed = float(profile.get("mouse_speed_factor", 1.0))
    jitter = float(profile.get("jitter_px", 1.25))
    overshoot_threshold = float(profile.get("overshoot_threshold_px", 400.0))

    # Per-SESSION neuromotor signature: vary the WindMouse force constants (G/W/M/D) a little per
    # profile so the trajectory GENERATOR itself differs person-to-person — not just the wind noise on
    # top (a fleet-fixed force field is a distribution a detector could model). Derived deterministically
    # from the profile's own draw (stable within a session, reproducible under seed), bounded to ±15%.
    g, w, m, d = _wm_params(profile)

    # Point count is MT x REPORT RATE: a faster-reporting mouse emits MORE samples over the SAME
    # movement, it does not make the hand move faster. Scaling here (rather than shortening dt
    # alone) keeps each person's movement time governed by Fitts + their speed factor while the
    # observable inter-event interval becomes a per-person constant.
    n_total = _fitts_points(distance, speed)
    _rate_ratio = 1.0
    try:
        _mp = float(profile.get("move_point_ms") or 0.0)
        if _mp > 0.0:
            _rate_ratio = max(0.4, min(2.6, 14.0 / _mp))
    except (TypeError, ValueError):
        _rate_ratio = 1.0
    if _rate_ratio != 1.0:
        n_total = max(6, min(110, int(round(n_total * _rate_ratio))))

    # Degenerate / sub-pixel move: emit a valid stationary stream of the min point count.
    if distance < 1.0:
        return [{"kind": "move", "x": int(round(x0)), "y": int(round(y0))} for _ in range(n_total)]

    # Corrective submovement (overshoot-and-settle) fires on LONG throws (past the px threshold) AND,
    # per the optimized-submovement model (Meyer 1988 / Elliott 2001), on a real fraction of SHORTER
    # rapid aimed moves too — human aiming corrects at ~30-50% across all distances, not only long
    # throws. A hard distance-only gate (≥400 px) made nearly every in-viewport move a single clean
    # ballistic arc with no correction = too-perfect motor tell. Weight the probability up for FASTER
    # movers (lower speed_factor = more ballistic overshoot); skip sub-40px nudges (no room to correct).
    _corrective = (distance >= overshoot_threshold) or (
        distance >= 40.0 and rng.random() < max(0.25, min(0.45, 0.46 - 0.08 * speed)))
    if _corrective:
        # Two-phase: fast WindMouse approach to an overshoot point past target, then ease-out settle.
        pct = rng.uniform(0.03, 0.12)
        ox = x1 + (x1 - x0) * pct
        oy = y1 + (y1 - y0) * pct
        n_settle = max(2, min(6, n_total // 3))
        n_main = max(2, n_total - n_settle)
        dense = _wind_mouse(x0, y0, ox, oy, rng, g=g, w=w, m=m, d=d)
        main = _resample_eased(dense, n_main)
        settle = _ease_out_settle(ox, oy, x1, y1, n_settle, rng)
        raw_pts = main + settle
    else:
        dense = _wind_mouse(x0, y0, x1, y1, rng, g=g, w=w, m=m, d=d)
        raw_pts = _resample_eased(dense, n_total)

    # Gaussian jitter on interior points; anchor first == start and last == end exactly.
    #
    # PER-POINT CADENCE (``dt_ms``): the raw-CDP chromium path used to dispatch every ``mouseMoved``
    # back-to-back with no delay and no explicit timestamp, so Chrome stamped them all within the
    # sub-ms wss round-trip → ``event.timeStamp`` deltas clustered near zero, a uniform fleet-wide
    # tell (real mouse hardware reports at ~60-125 Hz = ~8-16 ms spacing, WITH jitter). Because the
    # POINTS are already eased spatially (denser at the slow start/settle, sparser through the
    # cruise), a roughly-constant per-point time yields the correct accelerate/cruise/decelerate
    # REAL-TIME velocity envelope: dense points → many small waits over a short distance → slow.
    # We attach that per-point wait here (seed-reproducible via ``rng``, scaled by the session's
    # mouse_speed_factor, gaussian-jittered so no fixed interval); ``perform_ops`` sleeps it after
    # each chromium ``mouseMoved`` so the dispatch cadence — and thus Chrome's own receipt
    # timestamps — become human. Off-chromium the worker paces natively; the extra key is ignored.
    # Per-point interval is ~constant (the hardware REPORT RATE ~60-90 Hz, speed-independent) — a slow
    # person's move has MORE points over MORE time at the same sample rate, not the same points spread
    # slower. Previously base_ms DIVIDED by speed while _fitts_points MULTIPLIED points by speed, so the
    # two cancelled and TOTAL movement time was ~identical for every profile (an "elderly" 2.0 and a
    # "gamer" 0.5 finished a move in the same wall-clock ms) → the fleet's move-time distribution was
    # far too narrow = the single most modelable motor homogeneity tell. Decoupled: cadence stays
    # ~constant (default 14 ms ≈ 60 Hz, jittered per point below) so total MT now tracks point-count ∝
    # speed (the real ~2-4x person-to-person spread; ben.land / MacKenzie-Buxton Fitts).
    # R-4/R-5 (2026-10-04). ``move_point_ms`` defaulted to 14.0 and NO profile ever set it —
    # measured over 5,000 drawn profiles: ONE distinct value fleet-wide, so every soul's modal
    # inter-``mousemove`` interval was the same ~71 Hz. And the gaussian was floored with
    # ``max(2.0, ...)``, parking 0.68% of ALL moves on exactly 2.00 ms (a delta spike in the cohort
    # histogram). Now the rate is the PERSON's (``profiles.pick_profile`` draws ``pointer_hz`` from
    # the 60/72/100/125/144 Hz device population and stamps ``move_point_ms`` = its period) and each
    # gap is a log-normal around that period — positive by construction, no floor, right-skewed the
    # way a real OS input queue is.
    base_ms = float(profile.get("move_point_ms", 14.0))

    def _dt() -> float:
        return round(base_ms * math.exp(rng.gauss(0.0, 0.30)), 3)

    out: list[dict] = []
    last_i = len(raw_pts) - 1
    for i, (px, py) in enumerate(raw_pts):
        if 0 < i < last_i:
            px += rng.gauss(0.0, jitter)
            py += rng.gauss(0.0, jitter)
        out.append({"kind": "move", "x": int(round(px)), "y": int(round(py)),
                    "dt_ms": _dt()})
    out[0] = {"kind": "move", "x": int(round(x0)), "y": int(round(y0)), "dt_ms": _dt()}
    out[-1] = {"kind": "move", "x": int(round(x1)), "y": int(round(y1)), "dt_ms": _dt()}
    return out
