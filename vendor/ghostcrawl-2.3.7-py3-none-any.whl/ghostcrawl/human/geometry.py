"""ghostcrawl.human.geometry — scattered, human, non-repeating click targeting (shared).

Given a REAL element box, draw a click point from a truncated 2D gaussian INSIDE the box
(biased to centre, scattered ~0.5±0.18, clamped to a small margin) so the same control is never
clicked at the same pixel twice, and never dead centre. This is the "targets are real elements,
not guessed coords" requirement.

Owned by the ghostcrawl powerhouse (relocated from the analogsoul harness in 205-16) so BOTH the analog-soul drive and the
ghostopia ghostcrawl-provider share ONE off-centre-targeting implementation — no forked copy. The
math is unchanged: a seeded rng reproduces the identical point.
"""
from __future__ import annotations

import random
from typing import Any

__all__ = ["scatter_point"]


def scatter_point(
    box: dict[str, Any],
    rng: random.Random,
    *,
    mu: float = 0.5,
    sigma: float = 0.18,
    margin: float = 0.12,
) -> tuple[float, float]:
    """Draw a scattered click point inside ``box`` (a ``getBoundingClientRect``-shaped dict).

    Each axis fraction is a gaussian ``N(mu, sigma)`` truncated (resampled) into
    ``[margin, 1-margin]`` so the point stays comfortably inside the element yet varies every
    draw — never the exact centre, never the same offset twice. Returns absolute viewport coords.
    """
    x0 = float(box.get("x", 0.0))
    y0 = float(box.get("y", 0.0))
    w = max(1.0, float(box.get("width", 1.0)))
    h = max(1.0, float(box.get("height", 1.0)))

    def _frac() -> float:
        f = mu
        for _ in range(12):
            f = rng.gauss(mu, sigma)
            if margin <= f <= 1.0 - margin:
                return f
        return min(1.0 - margin, max(margin, f))

    return (x0 + _frac() * w, y0 + _frac() * h)
