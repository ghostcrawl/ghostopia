"""ghostcrawl.human.typing — W5 (2026-10-24) per-character human typing planner.

WHY THIS EXISTS
---------------
Before W5, ``_type_chromium``/``_type_firefox`` filled a field with a single
``Input.insertText`` (or, for mobile identities, one undifferentiated burst of IME key events).
A detector sampling ``keydown`` timestamps over a 40-character field therefore saw either **no key
events at all** (desktop insertText = a soft-keyboard tell in reverse) or a metronome: constant
inter-keystroke interval, zero mistypes, zero word shape. Real typing is neither — it has
per-transition flight times, key-hold dwell, and a small, honest error rate.

This module is a **planner**: it turns text + a per-session profile into a list of keystroke
events with timings. It drives NO browser API itself (the D-04 anti-pattern). The consumer is
``ghostcrawl.fleet.raw_session.RawSession._type`` → ``ghostcrawl.behavior.dispatch._type_*``,
which maps each planned event onto the engine's trusted-input path.

THE MODEL (adopted from the reference-engine behavioural model documented in our 2026-10
internal audit — the *model*, not anyone's code; we do NOT monkey-patch Playwright)
-------------------------------------------------------------------------------------------
1. **Flight time by hand transition.** Consecutive characters on the SAME hand are ~1.4-1.9x
   slower than an alternating-hand transition (the hand must travel back rather than pass off).
   Big jumps (e.g. ``q``→``p``) cost more than adjacent keys. Both are drawn per session, so no
   two sessions share a timing signature.
2. **Key-hold dwell.** Each key is held ~40-110 ms before release, drawn per keystroke.
3. **Mistype + notice + correct.** ~4% of alphanumeric characters mistype to a *neighbouring* key
   on the layout (not a random glyph — a real slip lands adjacent), then: a notice pause
   (100-300 ms), Backspace, a correction pause (50-150 ms), and the intended character retyped.
4. **Per-session deviation.** Every base rate is deviated per session (population-drawn like
   ``profiles.py``), never a static constant — two sessions of the same text must not share a
   keystroke-interval histogram (D-10 monoculture).

DETERMINISM: given the same ``seed``, a plan is byte-identical. That is what makes the unit tests
meaningful and what lets a session reproduce its own trace.

USAGE
-----
    from ghostcrawl.human.typing import plan_typing

    plan = plan_typing("hello world", seed=802318008)     # -> TypingPlan
    for ev in plan.events:                                 # each event is a plain dict
        ...
    plan.mistypes                                          # int, the events that slipped

The event dicts are engine-agnostic: ``{"kind": "key", "key": "h", "text": "h", "flight_ms": 84.2,
"dwell_ms": 61.0}``, ``{"kind": "backspace", ...}``, ``{"kind": "pause", "ms": 187.0}``.
``dispatch._type_*`` translates them to CDP/Juggler/WebKit trusted input.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

__all__ = [
    "TypingPlan",
    "plan_typing",
    "hand_of",
    "is_neighbour",
    "base_flight_ms",
]

# ── QWERTY physical model (US layout) ─────────────────────────────────────────────────────────
# Key centers in (row, column) units — row 0 = number row, col 0 = left edge. The hand split is
# the standard touch-typing one: y/h/n/b and everything right is the RIGHT hand; t/g/b are the
# LEFT hand's reach keys (b is genuinely ambiguous in the wild — left-hand b is the common
# touch-typing convention and the more common slip direction).
_ROWS: Tuple[str, ...] = (
    "1234567890-=",
    "qwertyuiop[]",
    "asdfghjkl;'",
    "zxcvbnm,./",
)
_HOME_ROW = 2
# Column at which each row's key is struck by the right hand (index of first right-hand key).
_RIGHT_FROM = (5, 5, 5, 5)

_POSITIONS: Dict[str, Tuple[int, int]] = {}
for _r, _row in enumerate(_ROWS):
    for _c, _ch in enumerate(_row):
        _POSITIONS[_ch] = (_r, _c)
        _POSITIONS[_ch.upper()] = (_r, _c)   # shift does not move the finger laterally

_SPACE = (4, 5)   # thumb, roughly centered below the board


def _pos(ch: str) -> Optional[Tuple[int, int]]:
    return _POSITIONS.get(ch) or (_SPACE if ch == " " else None)


def hand_of(ch: str) -> Optional[str]:
    """``"left"``/``"right"`` for a character, ``None`` when the layout does not place it.

    Digits 1-6 are the left hand's reach, 7-0 the right's (the common touch-typing split).
    """
    p = _pos(ch)
    if p is None:
        return None
    r, c = p
    if r == 0:
        return "left" if c <= 5 else "right"
    if ch == " ":
        return "thumb"
    return "left" if c < _RIGHT_FROM[r] else "right"


def is_neighbour(a: str, b: str) -> bool:
    """True when ``a`` and ``b`` are physically adjacent keys (a real slip lands here)."""
    pa, pb = _pos(a), _pos(b)
    if pa is None or pb is None:
        return False
    return abs(pa[0] - pb[0]) <= 1 and abs(pa[1] - pb[1]) <= 1


def _distance(a: str, b: str) -> float:
    """Euclidean distance in key units between two characters (0 for same/unplaced)."""
    pa, pb = _pos(a), _pos(b)
    if pa is None or pb is None:
        return 0.0
    return ((pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2) ** 0.5


# ── per-session drawn parameters ──────────────────────────────────────────────────────────────
# Bases are the population averages; every one is deviated per session (see ``_SessionRates``).
_BASE_FLIGHT_MS = 92.0          # mean same-hand-ish flight (moderate typist, ~50 WPM)
_BASE_SAME_HAND_MULT = (1.4, 1.9)   # same-hand penalty band (the measured human range)
_BASE_ALT_JITTER = (0.85, 1.15)     # alternating hands is the fast, low-variance case
_BASE_DWELL_MEAN_MS = 62.0
_BASE_DWELL_SIGMA_MS = 18.0
_BASE_MISTYPE_RATE = 0.04       # 4% of alnum characters
_NOTICE_MS = (100.0, 300.0)     # the beat before the correction starts
_CORRECT_MS = (50.0, 150.0)     # the beat between Backspace and the retype
_WORD_GAP_MS = (180.0, 420.0)   # pause after a word-space, beyond the space key's own flight

# Slips land on an adjacent key; pick from the 8-neighbourhood, never a far glyph.
_SLIP_OFFSETS: Tuple[Tuple[int, int], ...] = (
    (0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1),
)


@dataclass
class TypingPlan:
    """A planned keystroke sequence with per-event timings.

    ``events`` are plain dicts (engine-agnostic). ``mistypes`` counts the slips injected — a
    session that reports mistypes=0 over a long field is itself a tell, so the planner guarantees
    at least one slip per ~25 characters of alnum text when the rate says so.
    """
    text: str
    events: List[Dict[str, object]] = field(default_factory=list)
    mistypes: int = 0
    rates: Dict[str, float] = field(default_factory=dict)

    @property
    def total_ms(self) -> float:
        """Total planned wall-clock duration of the sequence."""
        total = 0.0
        for ev in self.events:
            total += float(ev.get("flight_ms", 0.0)) + float(ev.get("dwell_ms", 0.0)) \
                + float(ev.get("ms", 0.0))
        return total

    def key_events_only(self) -> List[Dict[str, object]]:
        """Just the key/backspace events (what a keystroke-timing detector would sample)."""
        return [ev for ev in self.events if ev["kind"] in ("key", "backspace")]


class _SessionRates:
    """Per-session deviations of every base rate (D-10: no two sessions share a signature)."""

    def __init__(self, rng: random.Random) -> None:
        self.flight_mean_ms = _BASE_FLIGHT_MS * rng.uniform(0.80, 1.25)
        # The same-hand penalty band itself moves per session — a fixed 1.4-1.9 for everyone is
        # a fleet-wide constant a detector can average out.
        self.same_hand_lo = rng.uniform(1.30, 1.55)
        self.same_hand_hi = self.same_hand_lo + rng.uniform(0.35, 0.60)
        self.dwell_mean_ms = max(38.0, _BASE_DWELL_MEAN_MS * rng.uniform(0.75, 1.30))
        self.dwell_sigma_ms = max(8.0, _BASE_DWELL_SIGMA_MS * rng.uniform(0.70, 1.40))
        self.mistype_rate = min(0.09, max(0.005, _BASE_MISTYPE_RATE * rng.uniform(0.5, 1.6)))
        self.notice_ms = rng.uniform(*_NOTICE_MS)
        self.correct_ms = rng.uniform(*_CORRECT_MS)
        self.word_gap_ms = rng.uniform(*_WORD_GAP_MS)

    def as_dict(self) -> Dict[str, float]:
        return {
            "flight_mean_ms": self.flight_mean_ms,
            "same_hand_lo": self.same_hand_lo,
            "same_hand_hi": self.same_hand_hi,
            "dwell_mean_ms": self.dwell_mean_ms,
            "dwell_sigma_ms": self.dwell_sigma_ms,
            "mistype_rate": self.mistype_rate,
            "notice_ms": self.notice_ms,
            "correct_ms": self.correct_ms,
            "word_gap_ms": self.word_gap_ms,
        }


def base_flight_ms(prev: str, cur: str, rates: _SessionRates, rng: random.Random) -> float:
    """Flight time (ms) from ``prev`` to ``cur``.

    Same hand -> the measured 1.4-1.9x penalty band; alternating hands -> the fast band. Distance
    adds on top (a ``q``→``p`` sweep is not a ``f``→``j`` pass-off).
    """
    ha, hb = hand_of(prev), hand_of(cur)
    if ha is None or hb is None:
        base_mult = 1.0
    elif ha == hb:
        base_mult = rng.uniform(rates.same_hand_lo, rates.same_hand_hi)
    else:
        base_mult = rng.uniform(*_BASE_ALT_JITTER)
    dist = _distance(prev, cur)
    # ~12% of the base per key-unit of travel — enough to shape word tails, not enough to look
    # machine-generated at the far end.
    return max(35.0, rates.flight_mean_ms * base_mult * (1.0 + 0.12 * dist))


def _slip(char: str, rng: random.Random) -> str:
    """A neighbouring-key slip for ``char`` (falls back to the char itself when unplaceable)."""
    p = _pos(char)
    if p is None:
        return char
    r, c = p
    row = _ROWS[r] if r < len(_ROWS) else ""
    for dr, dc in _SLIP_OFFSETS:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(_ROWS) and 0 <= nc < len(_ROWS[nr]):
            cand = _ROWS[nr][nc]
            # Never "slip" into a character we could not have been aiming at (e.g. a number when
            # typing a word) — real slips come from the same hand's adjacent fingers.
            if cand.isalnum() == char.isalnum():
                return cand
    return char


def plan_typing(
    text: str,
    *,
    profile: Optional[dict] = None,
    rng: Optional[random.Random] = None,
    seed: Optional[int] = None,
    mistype_rate: Optional[float] = None,
) -> TypingPlan:
    """Plan a human keystroke sequence for ``text``.

    Args:
        text: the characters to type.
        profile: an optional behavior profile (``profiles.pick_profile()``). Its
            ``mouse_speed_factor`` scales the whole session's tempo the way a faster/slower hand
            does; ``click_hold_sigma_ms`` widens the dwell draw. Absent = the population default.
        rng: an explicit rng (determinism).
        seed: a shorthand for ``random.Random(seed)`` — wins over ``rng``.
        mistype_rate: an explicit per-call override of the session's slip rate.

    Returns a :class:`TypingPlan`. The plan is deterministic for a given seed/rng state.
    """
    rng = rng or random.Random(seed)
    rates = _SessionRates(rng)

    # A faster/more precise hand (mouse_speed_factor < 1) types faster too — the same neuromotor
    # system drives both. This keeps a "gamer" identity's typing in the same shape as its pointer.
    if profile:
        speed = float(profile.get("mouse_speed_factor", 1.0))
        if speed > 0:
            rates.flight_mean_ms = max(35.0, rates.flight_mean_ms * speed)
            rates.dwell_mean_ms = max(30.0, rates.dwell_mean_ms * min(1.4, speed * 1.1))
        sigma = float(profile.get("click_hold_sigma_ms", 25.0))
        rates.dwell_sigma_ms = max(8.0, rates.dwell_sigma_ms * (sigma / 25.0))
    if mistype_rate is not None:
        rates.mistype_rate = min(0.15, max(0.0, float(mistype_rate)))

    plan = TypingPlan(text=text, rates=rates.as_dict())
    prev = ""
    alnum_total = sum(1 for ch in text if ch.isalnum())
    for ch in text:
        flight = base_flight_ms(prev, ch, rates, rng) if prev else rng.uniform(120.0, 260.0)
        dwell = max(28.0, rng.gauss(rates.dwell_mean_ms, rates.dwell_sigma_ms))

        slipped = bool(ch.isalnum()) and rng.random() < rates.mistype_rate
        if slipped:
            wrong = _slip(ch, rng)
            plan.events.append({"kind": "key", "key": wrong, "text": wrong,
                                "flight_ms": round(flight, 2), "dwell_ms": round(dwell, 2)})
            plan.mistypes += 1
            # Notice: the beat before the typist registers the error.
            plan.events.append({"kind": "pause", "ms": round(rates.notice_ms, 2)})
            plan.events.append({"kind": "backspace", "key": "Backspace", "text": "",
                                "flight_ms": round(rng.uniform(60.0, 130.0), 2),
                                "dwell_ms": round(max(28.0, rng.gauss(rates.dwell_mean_ms,
                                                                    rates.dwell_sigma_ms)), 2)})
            plan.events.append({"kind": "pause", "ms": round(rates.correct_ms, 2)})
            plan.events.append({"kind": "key", "key": ch, "text": ch,
                                "flight_ms": round(rng.uniform(55.0, 120.0), 2),
                                "dwell_ms": round(max(28.0, rng.gauss(rates.dwell_mean_ms,
                                                                    rates.dwell_sigma_ms)), 2)})
            prev = ch
            continue

        plan.events.append({"kind": "key", "key": ch, "text": ch,
                            "flight_ms": round(flight, 2), "dwell_ms": round(dwell, 2)})
        if ch == " ":
            # A word boundary carries the reader's pause, on top of the thumb's own flight.
            plan.events.append({"kind": "pause", "ms": round(rates.word_gap_ms, 2)})
        prev = ch

    # Guarantee the error shape over a long field: a session that types 40+ alphanumeric
    # characters with ZERO slips is itself a tell (nobody types that cleanly), so when the draw
    # produced none but the text was long enough to expect one, retro-fit a single slip at a
    # random alnum position. Short fields keep the pure draw — forcing an error into "a" would
    # be its own artefact. An EXPLICIT mistype_rate override wins over the floor: a caller who
    # asks for 0.0 (tooling, a self-test, a deterministic replay) gets a genuinely clean field.
    if (mistype_rate is None and alnum_total >= _MISTYPE_FLOOR_CHARS and plan.mistypes == 0):
        _inject_one_slip(plan, text, rng, rates)

    return plan


# Below this many alphanumeric characters the planner does NOT force a slip (see plan_typing).
_MISTYPE_FLOOR_CHARS = 25


def _inject_one_slip(plan: TypingPlan, text: str, rng: random.Random,
                     rates: _SessionRates) -> None:
    """Retro-fit exactly one slip+correction into ``plan`` at a random alphanumeric position."""
    idxs = [i for i, ch in enumerate(text) if ch.isalnum() and i > 0]
    if not idxs:
        return
    target = rng.choice(idxs)
    # Rebuild the plan with the slip spliced in at the right event offset. The planner emits one
    # event per character (plus pauses), so walk the source text in lockstep with the events.
    ch = text[target]
    wrong = _slip(ch, rng)
    slipped_events: List[Dict[str, object]] = [
        {"kind": "key", "key": wrong, "text": wrong,
         "flight_ms": round(base_flight_ms(text[target - 1], ch, rates, rng), 2),
         "dwell_ms": round(max(28.0, rng.gauss(rates.dwell_mean_ms, rates.dwell_sigma_ms)), 2)},
        {"kind": "pause", "ms": round(rates.notice_ms, 2)},
        {"kind": "backspace", "key": "Backspace", "text": "",
         "flight_ms": round(rng.uniform(60.0, 130.0), 2),
         "dwell_ms": round(max(28.0, rng.gauss(rates.dwell_mean_ms, rates.dwell_sigma_ms)), 2)},
        {"kind": "pause", "ms": round(rates.correct_ms, 2)},
        {"kind": "key", "key": ch, "text": ch,
         "flight_ms": round(rng.uniform(55.0, 120.0), 2),
         "dwell_ms": round(max(28.0, rng.gauss(rates.dwell_mean_ms, rates.dwell_sigma_ms)), 2)},
    ]
    # Locate the event index of the target character (event N corresponds to source char N before
    # any pause/backspace is interleaved; count only key events).
    key_seen = 0
    insert_at = len(plan.events)
    for i, ev in enumerate(plan.events):
        if ev["kind"] == "key":
            if key_seen == target:
                insert_at = i
                break
            key_seen += 1
    else:
        return
    plan.events[insert_at:insert_at + 1] = slipped_events
    plan.mistypes += 1
