"""ghostcrawl.human.device — device-appropriate input generators (AS-07, D-04).

The device layer speaks the two dialects a real person's hardware speaks, and NEVER mixes them:

  * A **desktop** identity issues keyboard chords — Ctrl+F to find, Ctrl+W to close a tab,
    Alt+Left to go back — as trusted-input ``{"kind": "key", "key": "Control+f"}`` dicts.
  * A **mobile** identity issues touch gestures — tap / swipe / pinch — as ordered
    ``{"kind": "touch", "phase": ..., "points": [...]}`` dicts in the widened GhostCrawl
    allow-list (the shape the touch dispatch consumes).

Which dialect is spoken is decided by the DRAWN IDENTITY's device class (``profile["device_class"]``),
never by the target host (D-06) — a phone is a phone on every page it visits. Every op is a plain
trusted-input dict; nothing here drives a browser input API directly (the D-04 anti-pattern).

Touch payload shape (matches the 198-04 dispatch contract):
  * ``points`` — a list of ``{"x": int, "y": int, "id": int}`` (per-finger id correlates a
    multi-touch gesture); EVERY op carries >= 1 point so it survives the trust-boundary sanitizer,
    which drops an empty gesture.
  * ``phase`` — a human alias in ``{"start", "move", "end", "cancel"}`` that orders the sequence.
"""
from __future__ import annotations

import math
import random

from ghostcrawl.human.timing import ease_out_exponent

__all__ = [
    "DESKTOP",
    "MOBILE",
    "SHORTCUTS",
    "is_mobile",
    "keyboard_shortcut",
    "tap",
    "swipe",
    "pinch",
]

DESKTOP = "desktop"
MOBILE = "mobile"

# Desktop keyboard chords a real person actually uses while browsing (chord string parsed into a
# modifier bitfield + base key by the downstream dispatch key helper).
SHORTCUTS: dict[str, str] = {
    "find": "Control+f",
    "close_tab": "Control+w",
    "new_tab": "Control+t",
    "reopen_tab": "Control+Shift+t",
    "reload": "Control+r",
    "address_bar": "Control+l",
    "back": "Alt+ArrowLeft",
    "forward": "Alt+ArrowRight",
    "page_down": "PageDown",
    "page_up": "PageUp",
    "top": "Home",
    "bottom": "End",
}

# Touch-gesture tuning. A gesture is anchored in the ONE-HANDED THUMB ZONE of the identity's
# real viewport (lower-middle, where a phone user's thumb actually rests) — never a fixed absolute
# point, which lands in a different place on every device. Travel is a viewport fraction and the
# finger path follows a flick velocity profile (fast launch, decelerating) with 9-16 touchmoves,
# matching a real 60-120Hz touch stream over a 100-300ms gesture. Per-instance jitter keeps no two
# gestures identical.
_TOUCH_ANCHOR_X_FRAC = (0.30, 0.70)   # thumb zone horizontal band (viewport fraction)
_TOUCH_ANCHOR_Y_FRAC = (0.55, 0.80)   # thumb zone vertical band (lower-middle)
_TOUCH_ANCHOR_JITTER_FRAC = 0.03
_SWIPE_TRAVEL_V_FRAC = (0.35, 0.60)   # vertical flick travel as a fraction of viewport height
_SWIPE_TRAVEL_H_FRAC = (0.45, 0.75)   # horizontal flick travel as a fraction of viewport width
_SWIPE_TRAVEL_MAX_PX = 460.0
_SWIPE_STEP_LO = 9
_SWIPE_STEP_HI = 16
_STEP_JITTER_PX = 5.0
# Fallback device surface when the caller/profile carries no viewport (a mid-size phone).
_DEFAULT_VIEWPORT = (390.0, 844.0)
_PINCH_HALF_SPAN_LO_PX = 60.0
_PINCH_HALF_SPAN_HI_PX = 160.0
_PINCH_STEP_LO = 3
_PINCH_STEP_HI = 6

_SWIPE_VECTORS = {
    "up": (0.0, -1.0),
    "down": (0.0, 1.0),
    "left": (-1.0, 0.0),
    "right": (1.0, 0.0),
}


def _device_class(profile: dict) -> str:
    """The drawn identity's device class (default desktop). Host-independent (D-06)."""
    return str(profile.get("device_class", DESKTOP)).lower()


def is_mobile(profile: dict) -> bool:
    """True iff the drawn identity is a touch (mobile) device."""
    return _device_class(profile) == MOBILE


def _pt(x: float, y: float, ident: int) -> dict:
    """A single non-negative int touch point with a correlation id."""
    return {"x": max(0, int(round(x))), "y": max(0, int(round(y))), "id": ident}


def _touch(phase: str, points: list[dict]) -> dict:
    return {"kind": "touch", "phase": phase, "points": points}


def keyboard_shortcut(
    name: str, profile: dict, rng: random.Random | None = None,
) -> list[dict]:
    """Emit a desktop keyboard chord as a ``key`` op list (empty on a mobile identity).

    ``name`` indexes :data:`SHORTCUTS` (find / close_tab / back …). A mobile identity has no
    keyboard, so it returns ``[]`` (device-appropriate). An unknown name is a no-op.
    """
    _ = rng  # deterministic; rng accepted for a uniform generator signature
    if is_mobile(profile):
        return []
    chord = SHORTCUTS.get(name)
    if not chord:
        return []
    return [{"kind": "key", "key": chord}]


def _viewport_dims(profile: dict) -> tuple[float, float]:
    """The identity's real render viewport (stamped on the profile by the drive)."""
    vp = profile.get("viewport") if isinstance(profile, dict) else None
    if isinstance(vp, dict):
        try:
            w = float(vp.get("width") or 0)
            h = float(vp.get("height") or 0)
            if w > 0 and h > 0:
                return w, h
        except (TypeError, ValueError):
            pass
    return _DEFAULT_VIEWPORT


def _anchor(rng: random.Random, profile: dict) -> tuple[float, float]:
    """A one-handed thumb-zone touch origin inside the identity's real viewport."""
    vw, vh = _viewport_dims(profile)
    ax = vw * rng.uniform(*_TOUCH_ANCHOR_X_FRAC) + rng.gauss(0.0, vw * _TOUCH_ANCHOR_JITTER_FRAC)
    ay = vh * rng.uniform(*_TOUCH_ANCHOR_Y_FRAC) + rng.gauss(0.0, vh * _TOUCH_ANCHOR_JITTER_FRAC)
    return max(0.0, ax), max(0.0, ay)


def tap(x: float, y: float, profile: dict, rng: random.Random | None = None) -> list[dict]:
    """A single-finger tap at ``(x, y)`` → ``touch`` start then end (empty on desktop)."""
    if not is_mobile(profile):
        return []
    rng = rng or random.Random()
    jx = x + rng.gauss(0.0, 6.0)   # fingertip placement jitter ~±5-10 px (Holz & Baudisch); 3 px was more precise than a real thumb
    jy = y + rng.gauss(0.0, 6.0)
    # MICRO-DRIFT ON RELEASE (2026-10-04): the touchend used to reuse the touchstart point
    # verbatim, so ``touchend.clientX/Y == touchstart.clientX/Y`` on 100% of taps (measured over
    # 100k). A finger rolls a pixel or two while it presses; after integer rounding a real stream
    # lands on the same pixel only part of the time, which is what this reproduces.
    return [
        _touch("start", [_pt(jx, jy, 0)]),
        _touch("end", [_pt(jx + rng.gauss(0.0, 1.15), jy + rng.gauss(0.0, 1.15), 0)]),
    ]


def swipe(direction: str, profile: dict, rng: random.Random | None = None) -> list[dict]:
    """A one-finger swipe in ``direction`` → an ordered start→move*→end touch sequence.

    ``direction`` ∈ {up, down, left, right}. Empty on a desktop identity (no touch surface).
    The finger keeps one stable point id for the whole gesture; interior points carry Gaussian
    jitter so the path is not a ruler-straight drag.
    """
    if not is_mobile(profile):
        return []
    rng = rng or random.Random()
    dx, dy = _SWIPE_VECTORS.get(direction, _SWIPE_VECTORS["up"])
    vw, vh = _viewport_dims(profile)
    sx, sy = _anchor(rng, profile)
    # A flick's travel scales with the device: a thumb swipe covers ~half the screen, never a
    # fixed pixel count (which is a full-screen fling on a small phone and a nudge on a tablet).
    frac = _SWIPE_TRAVEL_V_FRAC if dx == 0.0 else _SWIPE_TRAVEL_H_FRAC
    span = vh if dx == 0.0 else vw
    travel = min(span * rng.uniform(*frac), _SWIPE_TRAVEL_MAX_PX)
    ex, ey = sx + dx * travel, sy + dy * travel

    steps = rng.randint(_SWIPE_STEP_LO, _SWIPE_STEP_HI)
    # VELOCITY-DECAY EXPONENT PER GESTURE (2026-10-04). This used to be the literal ``2`` for every
    # swipe in the fleet: measured over 20,000 gestures the fitted exponent was a delta at 2.00
    # (p1 1.83 / p99 2.22, that spread coming only from the ±5 px jitter). Since the touchmove gaps
    # are paced by ONE digitizer period, a fixed exponent means a fixed NORMALISED velocity curve —
    # a single shape a detector can fit per gesture and see repeat fleet-wide. Drawn per gesture
    # from the real flick/drag mixture (``ghostcrawl.human.timing.ease_out_exponent``).
    decay = ease_out_exponent(rng)
    ops: list[dict] = [_touch("start", [_pt(sx, sy, 0)])]
    for i in range(1, steps):
        t = i / steps
        # Flick velocity profile: the finger covers most of the distance early (the launch) and
        # decelerates into the release — ease-out, not a constant-velocity ruler drag. The engine
        # derives the fling from these deltas, so the shape matters for the momentum too.
        f = 1.0 - (1.0 - t) ** decay
        mx = sx + (ex - sx) * f + rng.gauss(0.0, _STEP_JITTER_PX)
        my = sy + (ey - sy) * f + rng.gauss(0.0, _STEP_JITTER_PX)
        ops.append(_touch("move", [_pt(mx, my, 0)]))
    # The release keeps the flick's final drift (a hair past the last sample, jittered) — the
    # finger does not stop dead on a mathematically exact endpoint.
    rx = ex + rng.gauss(0.0, _STEP_JITTER_PX)
    ry = ey + rng.gauss(0.0, _STEP_JITTER_PX)
    ops.append(_touch("end", [_pt(rx, ry, 0)]))
    return ops


def pinch(scale: float, profile: dict, rng: random.Random | None = None) -> list[dict]:
    """A two-finger pinch → an ordered start→move*→end sequence of 2-point touch ops.

    ``scale`` > 1 diverges the fingers (zoom in); ``scale`` < 1 converges them (zoom out). Both
    fingers carry distinct ids (0 and 1) throughout. Empty on a desktop identity.
    """
    if not is_mobile(profile):
        return []
    rng = rng or random.Random()
    cx, cy = _anchor(rng, profile)
    start_half = rng.uniform(_PINCH_HALF_SPAN_LO_PX, _PINCH_HALF_SPAN_HI_PX)
    end_half = max(6.0, start_half * float(scale))

    steps = rng.randint(_PINCH_STEP_LO, _PINCH_STEP_HI)
    # 2026-10-04 — three fixed shapes removed (measured over 20,000 pinches):
    #   * both fingers carried the SAME jitter sample, so the pair was a rigid body whose relative
    #     noise was exactly zero and whose y-coordinates were byte-identical on 100% of frames;
    #   * the axis was exactly horizontal on every pinch ever emitted;
    #   * the span advanced LINEARLY (``start + (end-start)*t``) — a perfectly constant pinch
    #     velocity, with the step-delta CV measuring exactly 0.0 at p1.
    # A real two-finger pinch sits on an arbitrary axis, decelerates, and the two fingers neither
    # travel equally (the thumb moves less) nor jitter together.
    axis = rng.uniform(0.0, math.pi)          # the hand's own orientation, not the screen's
    ux, uy = math.cos(axis), math.sin(axis)
    decay = ease_out_exponent(rng)
    # Asymmetric travel: the anchoring finger covers 30-50% of what the moving one does.
    w0 = rng.uniform(0.30, 0.50)
    w1 = 1.0 - w0

    def _frame(phase: str, half0: float, half1: float) -> dict:
        # Independent per-finger jitter -> a non-zero relative-noise term, as real contacts have.
        return _touch(
            phase,
            [
                _pt(cx - half0 * ux + rng.gauss(0.0, _STEP_JITTER_PX),
                    cy - half0 * uy + rng.gauss(0.0, _STEP_JITTER_PX), 0),
                _pt(cx + half1 * ux + rng.gauss(0.0, _STEP_JITTER_PX),
                    cy + half1 * uy + rng.gauss(0.0, _STEP_JITTER_PX), 1),
            ],
        )

    delta = end_half - start_half
    # R-7 (2026-10-04): the pinch used to emit ONE ``start`` frame carrying BOTH contacts, so both
    # fingers landed on a single timestamp — measured 100% of 20,000 pinches. A real hand lands one
    # finger first (usually the anchoring thumb) and the second ~20-120 ms later, which the DOM sees
    # as TWO ``touchstart`` events: the first with one contact, the second carrying both. Emit that
    # pair; which finger is first is drawn per gesture. The replay side pays the inter-landing beat
    # (``timing.multi_touch_landing_gap``) when it sees a second consecutive ``start``.
    _h0 = start_half * 2.0 * w0
    _h1 = start_half * 2.0 * w1
    _first_is_0 = rng.random() < 0.5
    _solo = _frame("start", _h0, _h1)
    _solo_pts = list(_solo["points"])
    _solo = dict(_solo)
    _solo["points"] = [_solo_pts[0] if _first_is_0 else _solo_pts[1]]
    ops: list[dict] = [_solo, _frame("start", _h0, _h1)]
    for i in range(1, steps):
        t = i / steps
        f = 1.0 - (1.0 - t) ** decay
        half = start_half + delta * f
        ops.append(_frame("move", half * 2.0 * w0, half * 2.0 * w1))
    ops.append(_frame("end", end_half * 2.0 * w0, end_half * 2.0 * w1))
    return ops
