"""Generic navigation-INTENT core — a ghostcrawl (powerhouse) human-navigation primitive.

The ONE host-agnostic source of the "infinite-but-real" multi-page journey model: a satiation-driven
continuation probability (an engaging interest thread self-EXTENDS, a boring one self-ENDS), a
thread-biased NO-REVISIT target chooser, and a generic persona/depth model. Pure: stdlib + random +
dataclasses only; NO CdpRelay / playwright / affordance / per-site coupling (that stays in whichever
harness drives it).

BOTH harnesses consume this from the powerhouse (they never import each other):
  * ``analogsoul`` re-exports the shared MATH (``satiation_continue_p`` / ``update_engagement_gain``
    / ``thread_pick`` / ``crystallize_thread_lane`` + ``DEEPEN_DECAY`` / ``SATIATION_HORIZON_S``)
    via ``analogsoul.soul.journey_intent`` and keeps its OWN richer reelshuffle persona/economy.
  * ``ghostopia`` builds its ghost-journey orchestrator on the generic ``GhostPersona`` +
    ``draw_persona`` / ``deepen_base`` / ``nav_cap`` here.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

__all__ = [
    "DEEPEN_DECAY", "SATIATION_HORIZON_S", "VOLUME_CAP_FRACTION",
    "NAV_CEILING_BY_DEPTH", "NAV_RUNAWAY_GUARD", "DEEPEN_BASE",
    "SUPERFAN_NAV_BONUS", "SUPERFAN_DEEPEN_BONUS", "SUPERFAN_RATE",
    "DEPTH_ORDER", "DEPTH_WEIGHTS", "PREF_ORDER", "PREF_WEIGHTS",
    "satiation_continue_p", "update_engagement_gain", "thread_pick", "crystallize_thread_lane",
    "volume_capped", "GhostPersona", "draw_persona", "deepen_base", "nav_cap",
]

# --- shared constants -----------------------------------------------------------------------
# Willingness to keep exploring tapers each extra nav (natural).
DEEPEN_DECAY = 0.8
# Elapsed-time scale for the fatigue term (~10 min → strong fatigue).
SATIATION_HORIZON_S = 600.0
# D-04: every volume lever is clamped to 0.8x its realistic ceiling — a margin below the detectable edge.
VOLUME_CAP_FRACTION = 0.8
# Depth-shaped realistic nav ceilings (a binger works through far more pages than a skimmer). Each is
# 0.8-capped by ``volume_capped`` — the HEAVY TAIL comes from the satiation SHAPE, not an un-capped lever.
NAV_CEILING_BY_DEPTH = {"skimmer": 4, "diver": 10, "browser": 20}
NAV_RUNAWAY_GUARD = 40   # absolute safety guard (well above the human tail; never binds in practice)
# Per-hop deepen base by depth (a browser keeps going, a skimmer rarely does).
DEEPEN_BASE = {"skimmer": 0.10, "diver": 0.30, "browser": 0.55}
SUPERFAN_NAV_BONUS = 3        # the returning-lover walks deeper (still 0.8-capped)
SUPERFAN_DEEPEN_BONUS = 0.25  # ...and is more willing to open one more page
SUPERFAN_RATE = 0.15          # a minority archetype
DEPTH_ORDER = ("skimmer", "diver", "browser")
DEPTH_WEIGHTS = (0.45, 0.35, 0.20)
PREF_ORDER = ("movie", "tv", "either")
PREF_WEIGHTS = (0.45, 0.35, 0.20)


# --- shared MATH (single source; analogsoul re-exports these) -------------------------------
def satiation_continue_p(
    base_p: float, hop_index: int, elapsed_frac: float, engagement_gain: float
) -> float:
    """Satiation-driven continuation probability (replaces a flat per-hop decay).

    ``engagement_gain`` rises above 1 after a genuinely engaging (landed, on-thread) page and falls
    below 1 after a dud, so an engaging interest thread self-EXTENDS ("one more") and a boring one
    self-ENDS. ``fatigue`` grows with the hop count AND elapsed session time. The product yields a
    HEAVY-TAILED walk length organically (most sessions short, a real minority long) instead of a
    uniform clamp. Always < 0.95 (never a certainty). Pure — deterministic for its inputs.
    """
    fatigue = (DEEPEN_DECAY ** max(0, int(hop_index))) * max(0.15, 1.0 - 0.6 * float(elapsed_frac))
    p = float(base_p) * float(engagement_gain) * fatigue
    return max(0.0, min(0.95, p))


def update_engagement_gain(gain: float, *, landed: bool, on_thread: bool) -> float:
    """Evolve the engagement gain from the last page's quality (bounded, monotone-ish).

    A landed on-thread read is "good" → the soul wants one more (gain up); a missed page is a real
    dud → wind down sooner (gain down hard); an off-thread landed page is a mild cool-off. Clamped
    to [0.5, 1.3] so no single page can swing the whole walk.
    """
    if landed and on_thread:
        return min(1.3, float(gain) + 0.12)
    if not landed:
        return max(0.5, float(gain) - 0.25)
    return max(0.5, float(gain) - 0.08)


def thread_pick(
    pool: list[dict], thread_lane: str, visited: set[str], rng: random.Random, *, wander: bool = False
) -> "dict | None":
    """Thread-biased, NO-REVISIT target choice for a deepen loop.

    Prefer a FRESH card (href not yet opened this session — the anti-loop/anti-repetition guarantee)
    whose lane matches the session's interest thread, with a small off-thread wander so the journey
    reads as a coherent human interest thread ("liked this thriller → more like this") rather than a
    uniform random walk. Returns ``None`` when nothing fresh remains (the thread is exhausted → the
    walk ends naturally, never a revisit-loop tell). Host-agnostic (reads only affordance shape).
    """
    if not pool:
        return None
    fresh = [c for c in pool if str(c.get("href") or "") not in visited]
    if not fresh:
        return None  # everything reachable already visited → end the thread (no revisit tell)
    if thread_lane and thread_lane != "either" and not wander:
        on = [c for c in fresh if c.get("lane") in (thread_lane, "either")]
        if on and rng.random() < 0.8:
            return rng.choice(on)
    return rng.choice(fresh)


def crystallize_thread_lane(content_pref: str, first_card: "dict | None") -> str:
    """Anchor an interest thread lane from the persona pref, or the first real interest opened.

    A persona with a concrete lane lean anchors there; an ``either`` persona lets the thread
    crystallize on the lane of the first detail actually opened (a real "I clicked a movie → I'm in
    a movie mood" moment). Pure helper.
    """
    lane = str(content_pref or "either")
    if lane == "either" and isinstance(first_card, dict) and first_card.get("lane") in ("movie", "tv"):
        return str(first_card["lane"])
    return lane


def volume_capped(ceiling: float, *, fraction: float = VOLUME_CAP_FRACTION) -> int:
    """D-04: clamp a volume lever to ``fraction`` (0.8) of its realistic ``ceiling`` (floored int)."""
    import math
    return max(0, int(math.floor(float(ceiling) * fraction)))


# --- generic persona / depth model (ghostopia consumes this; analogsoul keeps its richer own) --
@dataclass(frozen=True)
class GhostPersona:
    """A generic per-journey persona: engagement depth + a content-lane lean.

    ``depth`` ∈ {skimmer, diver, browser} sets how far the journey tends to go; ``superfan`` is a
    minority archetype that browses deep with low pickiness; ``content_pref`` ∈ {movie, tv, either}
    seeds the interest thread; ``pickiness`` ∈ [0.25, 0.85] is how easily a target satisfies.
    """

    depth: str
    superfan: bool
    content_pref: str
    pickiness: float


def draw_persona(rng: random.Random) -> GhostPersona:
    """Draw ONE generic :class:`GhostPersona` (pure rng — host-agnostic).

    The superfan coin is drawn FIRST (its own draw) so it can coherently force browser depth while
    keeping the rng stream stable (the depth draw is always consumed). Fresh entropy → a unique
    persona; a fixed seed → reproducible (unit tests).
    """
    superfan = rng.random() < SUPERFAN_RATE
    depth = rng.choices(DEPTH_ORDER, weights=DEPTH_WEIGHTS, k=1)[0]
    if superfan:
        depth = "browser"  # a superfan browses deep
    content_pref = rng.choices(PREF_ORDER, weights=PREF_WEIGHTS, k=1)[0]
    pickiness = round(0.25 + 0.60 * rng.random(), 4)
    if superfan:
        pickiness = min(pickiness, 0.4)  # a lover is easily pleased
    return GhostPersona(depth=depth, superfan=superfan, content_pref=content_pref, pickiness=pickiness)


def deepen_base(persona: GhostPersona) -> float:
    """The base per-hop continuation probability for this persona (superfan-bonused, always < 1)."""
    p = DEEPEN_BASE.get(getattr(persona, "depth", "diver"), 0.30)
    if getattr(persona, "superfan", False):
        p = min(0.9, p + SUPERFAN_DEEPEN_BONUS)
    return p


def nav_cap(persona: GhostPersona) -> int:
    """The 0.8-clamped, runaway-guarded ceiling on full navigations for this persona (D-04).

    DEPTH-shaped (a browser/superfan binger's realistic ceiling is far higher than a skimmer's) but
    still 0.8-capped AND bounded by the absolute runaway guard — never an over-ceiling walk. The
    heavy-tailed length is produced by ``satiation_continue_p`` WITHIN this cap, not by the cap.
    """
    depth = str(getattr(persona, "depth", "diver"))
    ceiling = NAV_CEILING_BY_DEPTH.get(depth, 10)
    if getattr(persona, "superfan", False):
        ceiling += SUPERFAN_NAV_BONUS
    return max(1, min(NAV_RUNAWAY_GUARD, volume_capped(ceiling)))
