"""ghostcrawl.human — powerhouse human-navigation realism primitives.

Self-contained, dependency-light building blocks for authentic human interaction (neuromotor
trajectory, device tap/swipe, miss-click imperfection, momentum scroll, dwell timing, scatter
geometry, per-instance neuromotor profiles) + generic DOM affordance discovery. These are the ONE
source consumed BY the harnesses (analogsoul, ghostopia) — the harnesses import from here and never
from each other. Operator-internal (excluded from the public customer wheel).
"""
