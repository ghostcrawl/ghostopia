"""ghostcrawl.human.profiles — golden 'average human' profile + per-instance deviation (D-10).

The generative parameter model every downstream behavioral generator composes on. A single
golden profile (the average human) plus a weighted draw across five human *classes*, each knob
then deviated ±10% per instance so **no two instances are identical** (D-10) while staying inside
a bounded, human-plausible envelope.

Ported and ENRICHED from the verified in-repo analog
``stealth/playwright-stack/playwright_stack/human_input.py`` (``BEHAVIOR_PROFILES`` +
``pick_behavior_profile``) — NOT re-derived. The model is population-shaped and per-site-agnostic
(D-06): it depends only on the drawn human class, never on the target hostname.
"""
from __future__ import annotations

import os
import random

from ghostcrawl.human.timing import pointer_hz

__all__ = [
    "BEHAVIOR_PROFILES",
    "CORE_SCALAR_KNOBS",
    "ENRICHED_BASE",
    "golden_profile",
    "pick_profile",
]

# ---------------------------------------------------------------------------------------------
# Core neuromotor knobs (ported verbatim shape from the analog, lines 35-79).
# ---------------------------------------------------------------------------------------------

# Default = the average / moderate human. Golden profile is built off this class.
_MODERATE = {
    "mouse_speed_factor": 1.0,      # 1.0 = normal, <1 faster, >1 slower
    "jitter_px": 1.25,              # pointer jitter magnitude
    "click_hold_mean_ms": 92.0,     # mean click hold duration
    "click_hold_sigma_ms": 25.0,    # click hold std dev
    "overshoot_threshold_px": 400.0,  # min distance to trigger overshoot
    "idle_drift_px": 1.5,           # max idle micro-drift
}

BEHAVIOR_PROFILES: dict[str, dict[str, float]] = {
    "fast_precise": {
        "mouse_speed_factor": 0.7,
        "jitter_px": 0.8,
        "click_hold_mean_ms": 65.0,
        "click_hold_sigma_ms": 15.0,
        "overshoot_threshold_px": 500.0,
        "idle_drift_px": 0.8,
    },
    "moderate": dict(_MODERATE),
    "slow_careful": {
        "mouse_speed_factor": 1.5,
        "jitter_px": 1.8,
        "click_hold_mean_ms": 120.0,
        "click_hold_sigma_ms": 35.0,
        "overshoot_threshold_px": 300.0,
        "idle_drift_px": 2.2,
    },
    "elderly": {
        "mouse_speed_factor": 2.0,
        "jitter_px": 2.5,
        "click_hold_mean_ms": 160.0,
        "click_hold_sigma_ms": 50.0,
        "overshoot_threshold_px": 250.0,
        "idle_drift_px": 3.0,
    },
    "gamer": {
        "mouse_speed_factor": 0.5,
        "jitter_px": 0.5,
        "click_hold_mean_ms": 55.0,
        "click_hold_sigma_ms": 10.0,
        "overshoot_threshold_px": 600.0,
        "idle_drift_px": 0.5,
    },
}

# Weighted population — most humans are moderate; the tails are the fast/precise, careful,
# elderly, and gamer classes (analog lines 85-87).
_PRESET_ORDER = ("fast_precise", "moderate", "slow_careful", "elderly", "gamer")
# gamer trimmed 0.10→0.04 (the most bot-adjacent class: speed 0.5 + near-zero jitter = too-smooth/
# too-fast motion; 20% of a general movie audience being ultra-fast power-users over-weighted the
# most-synthetic profile). Freed 0.06 → moderate/slow_careful (the realistic consumer bulk).
_PRESET_WEIGHTS = (0.10, 0.54, 0.22, 0.10, 0.04)

# Every scalar knob that receives ±10% per-instance deviation. Kept as a public tuple so the
# tests (and downstream consumers) share one source of truth for "what is a bounded knob".
CORE_SCALAR_KNOBS: tuple[str, ...] = (
    "mouse_speed_factor",
    "jitter_px",
    "click_hold_mean_ms",
    "click_hold_sigma_ms",
    "overshoot_threshold_px",
    "idle_drift_px",
)

# ---------------------------------------------------------------------------------------------
# Enriched D-10 knobs the downstream generators need (scroll / imperfection / timing / planner).
# Base values = the average human; each numeric base is deviated ±10% per instance, EXCEPT
# scroll_depth_target which is a fresh per-instance draw in the human 30–70% band (AS-02).
# ---------------------------------------------------------------------------------------------
ENRICHED_BASE: dict[str, float] = {
    "miss_click_rate": 0.10,        # AS-06 ~10% miss-click population base
    "tab_switch_prob": 0.08,        # per-page probability of an away/back tab switch
}

# Enriched knobs deviated ±10% alongside the core scalars.
_ENRICHED_SCALAR_KNOBS: tuple[str, ...] = ("miss_click_rate", "tab_switch_prob")

# Scroll-depth intent band (AS-02 / D-08): a real per-instance target, not a fixed constant.
# WS-2 (2026-09-27): a hard uniform clamp to [0.30,0.70] erased BOTH real tails — the ~20% of
# readers who reach the bottom (~1.0) and the shallow skims (<0.25). Real scroll depth is a MIXTURE
# with those tails; _draw_scroll_depth() below produces it (median still ~0.55). LO/HI kept for the
# golden deterministic median only.
_SCROLL_DEPTH_LO = 0.30
_SCROLL_DEPTH_HI = 0.70
# Mixture weights for the real scroll-depth distribution (env-tunable for the Clarity fit).
_SCROLL_SHALLOW_W = float(os.getenv("GHOSTCRAWL_SCROLL_SHALLOW_W", "0.20"))  # shallow skims → [0.10,0.30]
_SCROLL_BOTTOM_W = float(os.getenv("GHOSTCRAWL_SCROLL_BOTTOM_W", "0.20"))    # bottom-reachers → [0.90,1.0]

# Pre-click hesitation window (ms) — a (lo, hi) range deviated per instance (AS-03/AS-06).
_PRE_CLICK_HESITATION_MS = (500.0, 2000.0)

# Reading-dwell log-normal params (AS-03) — mu/sigma of ln(dwell_seconds).
# WS-2 (2026-09-27): was {mu:1.1} (~3 s median) — a GLANCE mislabeled as a content READ. A real
# detail-page read is ~15-30 s; this is now ~20 s median with a heavy right tail. The short glance
# lives under timing.dwell("scan").
_READING_DWELL_LOGNORM = {
    "mu": float(os.getenv("GHOSTCRAWL_DWELL_READING_MU", "3.0")),
    "sigma": float(os.getenv("GHOSTCRAWL_DWELL_READING_SIGMA", "0.62")),
}


def _draw_scroll_depth(rng: random.Random) -> float:
    """Draw a per-instance scroll-depth target from the REAL mixture distribution (with tails).

    ~20% shallow skims (0.10-0.30), ~20% bottom-reachers (0.90-1.0), the ~60% majority a mid read
    (triangular mode ~0.55). Median ≈ 0.55, matching real content-site scroll depth while restoring
    the two tails a hard [0.30,0.70] clamp erased. Population-shaped, host-agnostic (D-06)."""
    r = rng.random()
    if r < _SCROLL_SHALLOW_W:
        return round(rng.uniform(0.10, 0.30), 4)
    if r < _SCROLL_SHALLOW_W + _SCROLL_BOTTOM_W:
        return round(rng.uniform(0.90, 1.0), 4)
    return round(rng.triangular(0.35, 0.80, 0.55), 4)

_DEVIATION_LO = 0.9
_DEVIATION_HI = 1.1


def _deviate(rng: random.Random, base: float) -> float:
    """Apply a bounded ±10% per-instance deviation to a scalar base."""
    return base * rng.uniform(_DEVIATION_LO, _DEVIATION_HI)


def golden_profile() -> dict:
    """The un-deviated golden 'average human' — the moderate class at base values.

    Complete (carries every enriched knob at its base) so callers can treat it as a
    fully-formed profile without a draw. Deterministic; takes no rng.
    """
    prof: dict = dict(BEHAVIOR_PROFILES["moderate"])
    prof.update(ENRICHED_BASE)
    prof["scroll_depth_target"] = (_SCROLL_DEPTH_LO + _SCROLL_DEPTH_HI) / 2.0  # 0.50 = median
    prof["pre_click_hesitation_ms"] = _PRE_CLICK_HESITATION_MS
    prof["reading_dwell_lognorm"] = dict(_READING_DWELL_LOGNORM)
    # The golden human carries the POPULATION MODE (125 Hz) deterministically — a fixed value is
    # correct here: this is the un-deviated reference profile, not a fleet draw.
    prof["pointer_hz"] = 125.0
    prof["move_point_ms"] = 1000.0 / 125.0
    prof["_name"] = "moderate"
    return prof


def pick_profile(rng: random.Random | None = None) -> dict:
    """Draw a per-instance behavior profile: weighted class + bounded ±10% per-knob deviation.

    Population-shaped and per-site-agnostic (D-06): the ONLY input is an rng — the drawn human
    class fully determines the base; the target host never enters the model. Same rng state →
    identical profile (determinism invariant); different seeds → at least one knob differs (D-10).
    """
    rng = rng or random.Random()
    chosen = rng.choices(_PRESET_ORDER, weights=_PRESET_WEIGHTS, k=1)[0]

    prof: dict = {}
    base = BEHAVIOR_PROFILES[chosen]
    for knob in CORE_SCALAR_KNOBS:
        prof[knob] = _deviate(rng, base[knob])

    # Enriched scalar knobs — same bounded ±10% deviation off the average-human base.
    for knob in _ENRICHED_SCALAR_KNOBS:
        prof[knob] = _deviate(rng, ENRICHED_BASE[knob])

    # Scroll-depth intent: a fresh per-instance draw from the REAL mixture (with tails, WS-2).
    prof["scroll_depth_target"] = _draw_scroll_depth(rng)

    # Pre-click hesitation window: deviate both endpoints by one shared factor (keeps lo<hi).
    factor = rng.uniform(_DEVIATION_LO, _DEVIATION_HI)
    lo, hi = _PRE_CLICK_HESITATION_MS
    prof["pre_click_hesitation_ms"] = (lo * factor, hi * factor)

    # Reading-dwell log-normal params — deviate mu/sigma per instance (bounded).
    prof["reading_dwell_lognorm"] = {
        "mu": _deviate(rng, _READING_DWELL_LOGNORM["mu"]),
        "sigma": _deviate(rng, _READING_DWELL_LOGNORM["sigma"]),
    }

    # POINTER REPORT RATE (R-4/R-5, 2026-10-04). The pointing device is part of the PERSON, so it
    # is drawn once here and every move of the session is paced by it (``trajectory`` reads
    # ``move_point_ms`` and scales its point count by the rate). Before this, no profile set the
    # knob at all and the whole fleet shared one 14 ms (~71 Hz) modal inter-``mousemove`` interval.
    prof["pointer_hz"] = pointer_hz(rng)
    prof["move_point_ms"] = 1000.0 / prof["pointer_hz"]

    prof["_name"] = chosen
    return prof
