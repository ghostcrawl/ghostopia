"""ghostcrawl.human.imperfection — miss/wrong-click + backtrack + session variance (AS-06, D-04).

"If it looks too perfect it's a bot" (D-10). Efficiency is the tell; imperfection is the cover.
This engine injects human error at human rates as **trusted-input** dicts / plain shape values,
and NEVER drives a browser pointer API directly (the ``run_tasks.py`` anti-pattern D-04 forbids).

Behaviors (ENRICHED from the verified analogs — NOT re-derived):
  * ``maybe_miss_click`` fires at ``profile["miss_click_rate"]`` (~10%) → a click on a jittered
    *nearby* wrong coord, then a corrective move + click on the real target (the ``_jitter_pos`` /
    typo-correction analog).
  * ``backtrack`` = an over-scroll-then-reverse, or a wrong-element-then-back move detour.
  * ``session_shape`` yields a per-instance session length (30-300 s) and page count (1-10) with
    real variance, so no two sessions are identical (D-10).
"""
from __future__ import annotations

import random

__all__ = ["maybe_miss_click", "backtrack", "session_shape"]

# Miss-click near-coord jitter (px) — a miss lands NEARBY, never a teleport.
_MISS_JITTER_LO = 18.0
_MISS_JITTER_HI = 70.0

# Session-shape bands (AS-06 / playbook 5).
_SESSION_LEN_LO_S = 30
_SESSION_LEN_HI_S = 300
_SESSION_PAGES_LO = 1
_SESSION_PAGES_HI = 10

# Backtrack over-scroll magnitude (px).
_BACKTRACK_SCROLL_LO = 120.0
_BACKTRACK_SCROLL_HI = 480.0
_BACKTRACK_WRONG_OFFSET = 90.0


def _draw_hold_ms(profile: dict, rng: random.Random) -> float:
    """Draw a human click-hold (press→release dwell) in ms from the profile.

    The profile carries ``click_hold_mean_ms``/``click_hold_sigma_ms`` per session (deviated per
    instance in soul.profiles), but they had ZERO consumers — every click fired as adjacent
    down→up with ~0 ms hold, a uniform fleet-wide tell (a real click holds ~50-160 ms). Draw a
    gaussian hold here, floored so it is never sub-human-fast."""
    mean = float(profile.get("click_hold_mean_ms", 92.0))
    sigma = float(profile.get("click_hold_sigma_ms", 25.0))
    return max(40.0, rng.gauss(mean, sigma))   # floor 40 ms = human minimum press→release (was 18 ms, sub-human)


def _down_up(x: int, y: int, hold_ms: float = 0.0) -> list[dict]:
    """A press/release pair at (x, y) with a human ``hold_ms`` dwell held between them.

    ``perform_ops`` sleeps on the interposed ``dwell`` op (chromium raw-CDP path) / the worker
    honors it natively (firefox/webkit), so the button is genuinely held down for ``hold_ms``
    before release — not an instantaneous down→up."""
    ops: list[dict] = [{"kind": "down", "x": x, "y": y}]
    if hold_ms > 0:
        ops.append({"kind": "dwell", "ms": int(round(hold_ms))})
    ops.append({"kind": "up", "x": x, "y": y})
    return ops


def _jitter_wrong(target: tuple[int, int], rng: random.Random) -> tuple[int, int]:
    """A nearby wrong coordinate around ``target`` (a miss, not a teleport)."""
    tx, ty = int(target[0]), int(target[1])
    mag_x = rng.uniform(_MISS_JITTER_LO, _MISS_JITTER_HI) * rng.choice((-1.0, 1.0))
    mag_y = rng.uniform(_MISS_JITTER_LO, _MISS_JITTER_HI) * rng.choice((-1.0, 1.0))
    return tx + int(round(mag_x)), ty + int(round(mag_y))


def maybe_miss_click(
    target: tuple[int, int],
    profile: dict,
    rng: random.Random | None = None,
) -> list[dict]:
    """Click ``target`` — but ~``miss_click_rate`` of the time, miss nearby then correct.

    Returns a trusted-input op list of ``down``/``up``/``move`` dicts. The final op always lands
    exactly on ``target``. On a miss the first op is a press on a jittered nearby (wrong) coord,
    followed by a corrective ``move`` onto the target and the real click.
    """
    rng = rng or random.Random()
    tx, ty = int(target[0]), int(target[1])
    rate = float(profile.get("miss_click_rate", 0.10))

    if rng.random() < rate:
        wx, wy = _jitter_wrong((tx, ty), rng)
        # The cursor must TRAVEL to the wrong spot before the misclick fires there — a mousedown at a
        # coord the pointer never moved to is a hard bot tell. So: move→(wx,wy), press (the miss),
        # then correct back onto the target in a couple of hops (not one straight teleport-move).
        # Each press carries its OWN drawn hold (the fumble press tends shorter than the deliberate one).
        ops: list[dict] = [{"kind": "move", "x": wx, "y": wy}]
        ops.extend(_down_up(wx, wy, _draw_hold_ms(profile, rng) * 0.7))
        mx = (wx + tx) // 2 + int(round(rng.uniform(-6.0, 6.0)))
        my = (wy + ty) // 2 + int(round(rng.uniform(-6.0, 6.0)))
        ops.append({"kind": "move", "x": max(0, mx), "y": max(0, my)})
        ops.append({"kind": "move", "x": tx, "y": ty})
        ops.extend(_down_up(tx, ty, _draw_hold_ms(profile, rng)))
        return ops

    # Clean click: land exactly on target, held for a human press duration.
    return _down_up(tx, ty, _draw_hold_ms(profile, rng))


def backtrack(profile: dict, rng: random.Random | None = None) -> list[dict]:
    """Emit a human backtrack: over-scroll-then-reverse, or wrong-element-then-back.

    Returns a trusted-input op list. The wheel variant contains a forward wheel and an
    opposite-sign correcting wheel; the move variant contains a there-and-back move pair.
    """
    rng = rng or random.Random()

    if rng.random() < 0.6:
        # Over-scroll past the intended stop, notice, and reverse.
        over = rng.uniform(_BACKTRACK_SCROLL_LO, _BACKTRACK_SCROLL_HI)
        x = max(0, int(round(rng.uniform(200, 600))))
        y = max(0, int(round(rng.uniform(200, 500))))
        return [
            {"kind": "wheel", "x": x, "y": y, "dy": int(round(over))},
            {"kind": "dwell", "ms": int(round(rng.uniform(180, 420)))},
            {"kind": "wheel", "x": x, "y": y, "dy": -int(round(over * rng.uniform(0.6, 1.0)))},
        ]

    # Move toward a wrong element, hesitate, then come back.
    bx = max(0, int(round(rng.uniform(300, 900))))
    by = max(0, int(round(rng.uniform(200, 600))))
    wrong_x = max(0, bx + int(round(rng.uniform(-_BACKTRACK_WRONG_OFFSET, _BACKTRACK_WRONG_OFFSET))))
    wrong_y = max(0, by + int(round(rng.uniform(-_BACKTRACK_WRONG_OFFSET, _BACKTRACK_WRONG_OFFSET))))
    return [
        {"kind": "move", "x": wrong_x, "y": wrong_y},
        {"kind": "dwell", "ms": int(round(rng.uniform(150, 380)))},
        {"kind": "move", "x": bx, "y": by},
    ]


def session_shape(profile: dict, rng: random.Random | None = None) -> dict:
    """Draw a per-instance session shape: ``{"length_s": int, "pages": int}`` with variance.

    Length is a log-normal-ish draw clamped to 30-300 s; page count is a small right-skewed
    draw clamped to 1-10. The two are loosely coupled (longer sessions tend to more pages) but
    carry independent noise so no two sessions are identical (D-10).
    """
    rng = rng or random.Random()

    # Session length: log-normal in seconds (median ~90s), clamped to the human band.
    length = int(round(2.718 ** rng.gauss(4.5, 0.55)))  # exp(4.5) ≈ 90 s median
    length = max(_SESSION_LEN_LO_S, min(_SESSION_LEN_HI_S, length))

    # Pages: scale loosely with length, plus independent noise; clamp to 1-10.
    base_pages = length / 45.0  # ~2s-per-page-plus-dwell heuristic
    pages = int(round(base_pages * rng.uniform(0.6, 1.4) + rng.gauss(0.0, 0.8)))
    pages = max(_SESSION_PAGES_LO, min(_SESSION_PAGES_HI, pages))

    return {"length_s": length, "pages": pages}
