"""ghostcrawl.human.scroll — momentum wheel deltas + overshoot-and-settle (AS-02, D-04).

Generates a human-realistic scroll as a **trusted-input wheel/dwell stream** for the GhostCrawl
job plan: a ``list[{"kind": "wheel", "x": int, "y": int, "dy": int}]`` interleaved with small
``{"kind": "dwell", "ms": int}`` gaps. It NEVER drives a browser wheel API directly — that
direct-execution style is the ``run_tasks.py`` anti-pattern D-04 forbids. The downstream planner
(198-08) hands these dicts to the session where the trusted-input sanitizer clamps them.

Physics (ENRICHED from the verified analog ``human_input.py::human_scroll`` — NOT re-derived):
  * Momentum loop = decaying wheel deltas ``dy = remaining * uniform(0.25, 0.65) + noise`` until
    the residual is tiny, so a page is nibbled across many events rather than one giant jump.
  * Per-visit **depth intent** = ``profile["scroll_depth_target"]`` (a per-instance draw in the
    human 30-70% band, AS-02 / D-08) applied to the page's *scrollable* height — population-shaped,
    never a per-site hardcode (D-06).
* ~10% of passes **overshoot** the final delta by 10-30 px and then dispatch a compensating
     reverse wheel after a 200-400 ms settle (trackpad/wheel mass); net scroll still equals target.
   * A ~4% minority **scroll back up** partway after reaching depth (the "did I read that?"
     glance) then re-scroll down to target — net still equals target.
   * ~8% of passes are a **fast flick**: the same decaying momentum loop with a MUCH tighter
     inter-event cadence (someone speed-scrolling a long page). Cadence only — the deltas and
     the net landing target are untouched, so no two pages scroll at any constant velocity.
   * Inter-event gaps are **soft-edged beats** (``human.timing.beat``) around a ~12-55 ms band, so
     the cadence is non-periodic AND the cohort histogram has no vertical wall (2026-10-04, R-3:
     the gaps used to be a flat ``uniform(12, 55)`` rectangle — plausible per draw, a rectangle in
     aggregate, and scroll cadence is one of the most-sampled behaviours a detector collects).
   * A ~62% majority of passes are a **discrete mouse wheel**, whose ``deltaY`` is an integer
     multiple of the device's notch (100 or 120 px); the rest are a precision touchpad emitting
     continuous deltas (2026-10-04, R-3). The quantizer carries its rounding residual forward, so
     the NET landing depth is unchanged. One device per pass — nobody swaps mice mid-scroll.
"""
from __future__ import annotations

import os
import random

from ghostcrawl.human.timing import beat

__all__ = ["scroll", "wheel_notch_px", "SCROLL_OVERSHOOT_PROBABILITY",
           "SCROLL_BACKUP_PROBABILITY", "SCROLL_FAST_PROBABILITY",
           "WHEEL_NOTCH_CHOICES", "WHEEL_NOTCH_SHARE"]

# ---- wheel DEVICE CLASS (the ONE source; analogsoul's drive caches a per-session draw off it) ----
# A real discrete mouse wheel emits a QUANTIZED deltaY — whole notches, 100 px on Linux/Windows
# Chrome and 120 px on some setups — while a precision touchpad emits small continuous deltas. A
# fleet that only ever emits continuous arbitrary deltas reads as 100% touchpad users, which no
# real population is. Env opt-out: GHOSTCRAWL_WHEEL_NOTCH=0.
WHEEL_NOTCH_CHOICES = (100.0, 120.0)
WHEEL_NOTCH_SHARE = 0.62


def wheel_notch_px(rng: random.Random | None = None) -> float | None:
    """Draw ONE pointing-device wheel quantum in px, or ``None`` for a precision-touchpad draw.

    Drawn once per session/pass by the caller and cached there — a human does not swap pointing
    devices mid-visit. Shared by ``human.scroll.scroll`` and the analogsoul drive's wheel path so
    the quantum population lives in exactly one place (no primitive fork).
    """
    if os.environ.get("GHOSTCRAWL_WHEEL_NOTCH", "1").strip().lower() not in (
            "1", "true", "yes", "on"):
        return None
    rng = rng or random.Random()
    if rng.random() >= WHEEL_NOTCH_SHARE:
        return None
    return rng.choice(WHEEL_NOTCH_CHOICES)

# Overshoot-and-settle tuning (analog parity: human_scroll lines 388-455).
# Deliberately drawn from MUTUALLY EXCLUSIVE buckets with the backup quirk so the aggregate
# reverse-wheel rate stays inside the band the overshoot test asserts (a human never does BOTH
# a tiny overshoot settle AND a big scroll-back-up on the same pass).
SCROLL_OVERSHOOT_PROBABILITY = 0.07
SCROLL_BACKUP_PROBABILITY = 0.04
_OVERSHOOT_MIN_PX = 10.0
_OVERSHOOT_MAX_PX = 30.0
_SETTLE_MIN_MS = 200.0
_SETTLE_MAX_MS = 400.0

# Scroll-back-up tuning: after reaching depth, reverse a chunk of the scroll, pause to "re-read",
# then scroll forward again to target.
_BACKUP_TRAVEL_LO = 0.08        # fraction of scrollable height scrolled back up
_BACKUP_TRAVEL_HI = 0.28
_BACKUP_REHOLD_MIN_MS = 300.0   # the "wait, what was that?" re-read pause
_BACKUP_REHOLD_MAX_MS = 950.0

# Fast-flick tuning: the fraction of passes that speed-scroll (compressed cadence).
SCROLL_FAST_PROBABILITY = 0.08
_FAST_GAP_FACTOR_LO = 0.40      # gap multiplier — a fast flick ~2-2.5x faster than normal
_FAST_GAP_FACTOR_HI = 0.62

# Momentum-loop tuning.
_DELTA_FRACTION_LO = 0.25
_DELTA_FRACTION_HI = 0.65
_DELTA_NOISE_PX = 8.0        # symmetric per-event delta noise
_RESIDUAL_STOP_PX = 3.0      # drain the remaining distance below this in one final event
_GAP_MIN_MS = 12.0
_GAP_MAX_MS = 55.0

# Wheel-event pointer location: a jittered point inside the viewport (coords stay >= 0).
_POINTER_JITTER_PX = 40.0


def scroll(
    page_height: float,
    viewport_h: float,
    profile: dict,
    rng: random.Random | None = None,
) -> list[dict]:
    """Build a momentum scroll to the profile's depth target as wheel/dwell dicts.

    Args:
        page_height: full content height of the page (px).
        viewport_h:  visible viewport height (px).
        profile:     a profile from ``soul.profiles`` — reads ``scroll_depth_target`` (0.30-0.70)
                     and ``mouse_speed_factor`` (scales the inter-event gap cadence).
        rng:         deterministic RNG; same seed reproduces the identical stream.

    Returns:
        ``list[{"kind": "wheel", "x": int, "y": int, "dy": int}]`` interleaved with
        ``{"kind": "dwell", "ms": int}`` gaps. Net wheel dy ≈ target * scrollable height.
    """
    rng = rng or random.Random()
    speed = float(profile.get("mouse_speed_factor", 1.0))
    target_frac = float(profile.get("scroll_depth_target", 0.5))

    scrollable = max(0.0, float(page_height) - float(viewport_h))
    total_dy = scrollable * target_frac

    # Per-pass quirks — mutually exclusive overshoot vs. big backup (a human does one, not both)
    # so the aggregate reverse-wheel rate stays in the asserted band; "fast" is cadence-only.
    _ra = rng.random()
    overshoot_active = _ra < SCROLL_OVERSHOOT_PROBABILITY
    backup_active = SCROLL_OVERSHOOT_PROBABILITY <= _ra < (
        SCROLL_OVERSHOOT_PROBABILITY + SCROLL_BACKUP_PROBABILITY)
    fast_active = rng.random() < SCROLL_FAST_PROBABILITY
    # ONE pointing device for the whole pass: a discrete wheel (quantized deltaY) or a precision
    # touchpad (continuous). R-3, 2026-10-04.
    notch = wheel_notch_px(rng)

    # Pointer anchor: a stable jittered point in the lower-middle of the viewport.
    px = max(0, int(round(viewport_h * 0.5 + rng.gauss(0.0, _POINTER_JITTER_PX))))
    py = max(0, int(round(viewport_h * 0.5 + rng.gauss(0.0, _POINTER_JITTER_PX))))

    ops: list[dict] = []
    # Quantizer residual: a discrete wheel can only emit WHOLE notches, so the fractional part of
    # every bite is carried into the next event. That keeps the NET landing depth identical to the
    # continuous path (the depth test's contract) while every emitted deltaY is a real notch count.
    carry = 0.0

    def _emit_wheel(dy: float) -> None:
        nonlocal carry
        out = float(dy)
        if notch:
            want = out + carry
            n = int(round(want / notch))
            if n == 0:
                # Less than half a notch: the wheel does not click at all — bank it and move on.
                carry = want
                return
            out = n * notch
            carry = want - out
        ops.append({"kind": "wheel", "x": px, "y": py, "dy": int(round(out))})

    def _emit_gap() -> None:
        # Soft-edged beat instead of a flat uniform: the band endpoints are themselves jittered and
        # the body clusters in the interior, with a small tail for a dispatch hitch (R-3).
        gap = beat(_GAP_MIN_MS / 1000.0, _GAP_MAX_MS / 1000.0, rng,
                   centre=0.40, tail_p=0.05, tail_mult=2.0) * 1000.0 * speed
        if fast_active:
            gap *= rng.uniform(_FAST_GAP_FACTOR_LO, _FAST_GAP_FACTOR_HI)
        ops.append({"kind": "dwell", "ms": int(round(gap))})

    # Nothing (or almost nothing) to scroll: emit a single tiny nudge and return.
    if total_dy < _RESIDUAL_STOP_PX:
        if scrollable > 0.0 and total_dy > 0.0:
            _emit_wheel(total_dy)
        return ops

    # A discrete wheel cannot overshoot by 17 px — its smallest possible overshoot is ONE notch.
    # A touchpad's overshoot is the continuous 10-30 px drift it always was.
    overshoot_amount = 0.0
    if overshoot_active:
        overshoot_amount = (float(notch) if notch
                            else rng.uniform(_OVERSHOOT_MIN_PX, _OVERSHOOT_MAX_PX))

    # Decaying-delta momentum loop: consume `remaining` in shrinking bites.
    remaining = total_dy
    while remaining > _RESIDUAL_STOP_PX:
        fraction = rng.uniform(_DELTA_FRACTION_LO, _DELTA_FRACTION_HI)
        dy = remaining * fraction + rng.uniform(-_DELTA_NOISE_PX, _DELTA_NOISE_PX)
        # Never let a noisy bite exceed what is left (keeps the net honest).
        if dy > remaining:
            dy = remaining
        if dy <= 0:
            dy = min(remaining, _RESIDUAL_STOP_PX)
        _emit_wheel(dy)
        remaining -= dy
        _emit_gap()

    # Final residual — with the optional overshoot rolled into the last forward event...
    if remaining > 0.0 or overshoot_active:
        _emit_wheel(remaining + overshoot_amount)
        # ...then a settle pause and a compensating reverse wheel so the net equals target.
        if overshoot_active:
            # Soft-edged settle (R-3): the eye-to-hand correction beat is right-skewed, not a
            # 200-400 ms rectangle.
            ops.append({"kind": "dwell", "ms": int(round(beat(
                _SETTLE_MIN_MS / 1000.0, _SETTLE_MAX_MS / 1000.0, rng,
                centre=0.38, tail_p=0.06) * 1000.0))})
            _emit_wheel(-overshoot_amount)

    # Scroll back up partway, pause to re-read, then re-scroll down to target ("did I read that?").
    # Net stays equal to target because the reverse AND the re-forward travel the same amount.
    if backup_active:
        back_up = max(4.0, scrollable * rng.uniform(_BACKUP_TRAVEL_LO, _BACKUP_TRAVEL_HI))
        # Reverse up in 1-2 bites (a single fast up-nudge back to the earlier spot).
        _emit_wheel(-back_up)
        ops.append({"kind": "dwell", "ms": int(round(beat(
            _BACKUP_REHOLD_MIN_MS / 1000.0, _BACKUP_REHOLD_MAX_MS / 1000.0, rng,
            centre=0.36, tail_p=0.08) * 1000.0))})
        # Re-scroll forward to target in shrinking bites (same momentum signature).
        re_remaining = back_up
        while re_remaining > _RESIDUAL_STOP_PX:
            fraction = rng.uniform(_DELTA_FRACTION_LO, _DELTA_FRACTION_HI)
            dy = re_remaining * fraction + rng.uniform(-_DELTA_NOISE_PX, _DELTA_NOISE_PX)
            dy = min(re_remaining, max(dy, _RESIDUAL_STOP_PX))
            _emit_wheel(dy)
            re_remaining -= dy
            _emit_gap()
        if re_remaining > 0.0:
            _emit_wheel(re_remaining)

    return ops
