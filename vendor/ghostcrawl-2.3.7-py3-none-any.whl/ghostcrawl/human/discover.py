"""Generic DOM affordance-discovery JS — a ghostcrawl (powerhouse) human-navigation primitive.

Enumerates a loaded page's clickable affordances (shuffle / card / category / reward / home /
other) + a generic budget indicator, as ``getBoundingClientRect`` boxes, purely from what the page
RENDERS — no per-site selectors, no hardcoded coordinates (host-agnostic). The optional ad-CDN
signature table (``__AD_CDN_SIGS_JSON__``) classifies ``ad`` affordances by creative-host regex;
callers that do not care about ad classification (e.g. plain navigation) use the default empty
table via :data:`DISCOVER_JS`. This is the ONE source of the discovery JS; the harnesses
(analogsoul, ghostopia) consume it FROM ghostcrawl and never re-author it.
"""
from __future__ import annotations

import json
from typing import Sequence

__all__ = [
    "DISCOVER_JS_TEMPLATE", "build_discover_js", "DISCOVER_JS",
    "IS_PERCEPTIBLE_FN_JS", "PERCEPTIBLE_OPACITY_FLOOR", "REACH_MAX_VH",
]

# Reachability funnel (deep-dive 3 §4.1 stage-2): the maximum below-fold distance, in viewport-
# heights, at which a content-nav affordance is even surfaced into the `below_fold` pool. No human
# scrolls many screens to click a random card, so beyond this the affordance is dropped at discovery
# (the drive-layer reachability coin applies the slightly-tighter 2.5vh behavioural cap + a distance
# decay on top; this is only the discovery ceiling, kept a touch higher so the coin can still SEE and
# DECLINE a near-edge item — which is what makes the funnel an auditable curve, not a cliff).
REACH_MAX_VH = 3.0

# The ONE perception notion (deep-dive 3 §2 — "unify the three probes behind one helper").
# A human cannot act on what they cannot perceive OR cannot interact with. This is the single
# hard boolean prefilter shared by discovery and (via import) the consent / modal / push /
# viewability probes, so there is one definition of "visible" instead of three drifting ones.
#   * display:none / visibility:hidden / zero-size  → not shown.
#   * pointer-events:none                           → a human's click passes through it (computed
#     value already reflects CSS inheritance, so checking the element itself suffices).
#   * EFFECTIVE opacity (own × a bounded ancestor chain) below the floor → sub-perceptual in a
#     glance; getComputedStyle(el).opacity misses a transparent PARENT, so we multiply down.
# Floor = 0.05 (justified, not magic): it is the glance contrast-detection floor for a filled
# element over a typical background, AND it unifies with the viewability/overlay probes that
# already cut at 0.05 — one number across the codebase. It is only a PREFILTER: the press is
# still gated by hover-then-verify (topmost-hit-test on the fresh post-scroll rect), so the floor
# only has to be conservative, not exact. Degrades OPEN (a probe failure never blinds discovery).
PERCEPTIBLE_OPACITY_FLOOR = 0.05
IS_PERCEPTIBLE_FN_JS = r"""
  function _isPerceptible(el) {
    try {
      if (!el || !el.getBoundingClientRect) return true;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return false;
      let n = el, eff = 1.0, hops = 0;
      for (; n && hops < 6; n = n.parentElement, hops++) {
        const s = getComputedStyle(n);
        if (s.display === 'none' || s.visibility === 'hidden') return false;
        if (hops === 0 && s.pointerEvents === 'none') return false;
        const o = parseFloat(s.opacity);
        if (!isNaN(o)) eff *= o;
        if (eff < 0.05) return false;
      }
      return true;
    } catch (e) { return true; }
  }
"""

DISCOVER_JS_TEMPLATE = r"""
(() => {
  const vw = window.innerWidth || 0, vh = window.innerHeight || 0;
  __IS_PERCEPTIBLE_FN__
  const out = {shuffle: [], card: [], category: [], reward: [], ad: [], home: [], other: [],
               below_fold: [],
               budget: {remaining: null, total: null}, gates_enabled: true};
  // Site gates (shuffle budget / unlocks) are read from what the page RENDERS, the way a person
  // sees them — the site advertises nothing to its visitors. Gates are on only when the page
  // carries the shuffle-budget state or a gate panel. When off the soul has NO gate knowledge:
  // rewards are never surfaced and the shuffle budget is not treated as limiting. An explicit
  // data-rf-gates (older replicas) still wins when present.
  try {
    const b = document.body;
    const flag = b.getAttribute('data-rf-gates');
    out.gates_enabled = flag !== null
      ? flag !== '0'
      : (b.hasAttribute('data-rotate-daily')
         || !!document.querySelector('.detail-gate, .lane-gate, .gate-panel, .rotate-pill'));
  } catch (e) { out.gates_enabled = true; }
  const seen = new Set();
  // Ad-network CDN signatures (host-agnostic, D-11): keyed on the SERVING network's CDN host, never
  // the replica site host. A native / self-injecting ad format mounts a cross-origin iframe or img
  // whose URL points at the network's CDN — that URL is readable cross-origin, so a FILLED real
  // creative can be attributed to its network and treated as a certified+filled clickable surface
  // even when the site's ad container carries a different (or no) data-ads-network attribute.
  const _AD_CDN_SIGS = (__AD_CDN_SIGS_JSON__).map((e) => [e[0], new RegExp(e[1], 'i')]);
  const _adHost = (u) => { try { return new URL(u, location.href).hostname || ''; } catch (e) { return ''; } };
  const _adNetFromUrl = (u) => { const h = _adHost(u); if (!h) return ''; for (const s of _AD_CDN_SIGS) if (s[1].test(h)) return s[0]; return ''; };
  const _adNetFromCreative = (el) => {
    if (!el || !el.querySelectorAll) return '';
    for (const node of el.querySelectorAll('iframe[src], img[src]')) {
      const n = _adNetFromUrl(node.getAttribute('src') || node.src || '');
      if (n) return n;
    }
    return '';
  };
  // Which ad networks' loader scripts are present on the page (unambiguous fallback attribution for
  // a filled box whose creative URL is opaque — e.g. an about:blank iframe written by the loader).
  const _adPageNets = new Set();
  try {
    for (const s of Array.from(document.querySelectorAll('script[src]'))) {
      const n = _adNetFromUrl(s.getAttribute('src') || s.src || '');
      if (n) _adPageNets.add(n);
    }
  } catch (e) {}
  const rewardKind = (blob) => {
    if (/refill|more shuffl|shuffle.*(refill|back|credit)|out of shuffl|top.?up/.test(blob))
      return 'refill-budget';
    if (/genre|categor/.test(blob)) return 'unlock-category';
    if (/detail|title|movie|tv|show|unlock|full/.test(blob)) return 'unlock-detail';
    return 'unknown';
  };
  const classify = (el, text, href) => {
    const t = (text || '').toLowerCase();
    const h = (href || '').toLowerCase();
    const id = ((el.id || '') + ' ' + (el.className || '')).toString().toLowerCase();
    const aria = (el.getAttribute && (el.getAttribute('aria-label') || '') || '').toLowerCase();
    const adslot = (el.getAttribute && el.getAttribute('data-ad-slot')) || '';
    const rk = ((el.getAttribute && (el.getAttribute('data-reward') ||
                 el.getAttribute('data-reward-kind') || el.getAttribute('data-ad') || '')) || '')
                 .toLowerCase();
    const blob = t + ' ' + id + ' ' + aria + ' ' + rk;
    // An ad SURFACE (banner/slot container) — distinct from a REWARD gate (a "watch ad to unlock"
    // control). Discovered so a session can naturally notice it (impression) and model a realistic
    // per-format human behavior (ignore / scroll-past / notice+close / hide-X / deny / rare brush).
    // NOT a reward gate. Host-agnostic: matches the generic ad-container classes AND any network's
    // own mount marker (ExoClick `ins.eas{hash}` / `[data-zoneid]`, adsbygoogle, etc.).
    const isExoIns = (el.tagName === 'INS' && (el.getAttribute('data-zoneid') ||
                      /^eas[0-9a-f]/i.test(el.className || '') || /adsbyexoclick/i.test(id)));
    if (adslot || isExoIns || /\bad-unit\b|adsbygoogle|\bad-banner\b|\bad-slot\b|\bad-exoclick\b/.test(id))
      return {cls: 'ad', kind: (adslot || 'ad')};
    if (rk || /watch ad|watch an ad|rewarded|view ad|watch to|unlock|watch video to/.test(blob))
      return {cls: 'reward', kind: rewardKind(rk + ' ' + blob)};
    // 1.10 SITE IA: a brand/logo/home link is a first-class affordance (return to the home page /
    // start over). Classified BEFORE shuffle because a brand wordmark ("ReelShuffle") contains
    // "shuffle" and would otherwise be mistaken for a reshuffle control — clicking it would then
    // silently RELOAD the home page (the no-home-reload tell). The nav shuffle button carries the
    // js-main-shuffle/data-skeleton marker and never matches here.
    const _isBrand = /(^|\s)brand(\s|$)|(^|\s)logo(\s|$)/.test(id)
        || /home|logo/.test(aria) || /^(home|start|start over|back to top)$/i.test(t);
    if (_isBrand && !/js-main-shuffle|nav-shuffle/.test(id))
      return {cls: 'home', kind: null};
    if (/shuffl|reshuffl|surprise|spin|another one|next pick|randomi/.test(blob))
      return {cls: 'shuffle', kind: null};
    if (/genre|categor|browse|popular|trending|discover/.test(blob)
        || /\/genre\b|\/categor|\/browse\b|\/popular\b|\/trending\b/.test(h))
      return {cls: 'category', kind: null};
    if (/\/(movie|tv|film|show|title|watch|detail|video|trailer)\b/.test(h)
        || /watch|play|detail|more info|trailer/.test(t)) {
      const lane = /\btv\b|show|series/.test(t + ' ' + h) ? 'tv'
                 : (/movie|film/.test(t + ' ' + h) ? 'movie' : 'either');
      return {cls: 'card', kind: lane};
    }
    return {cls: 'other', kind: null};
  };
  const nodes = Array.from(document.querySelectorAll(
    'a[href], button, [role="button"], [onclick], [data-reward], [data-ad], ' +
    '.ad-unit, [data-ad-slot], ins.adsbygoogle, ins[data-zoneid], ins[class^="eas"], ' +
    '.ad-exoclick-sticky, [class*="in-page-push" i], [class*="inpage" i], [id*="exo" i]'));
  for (const el of nodes) {
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    // Horizontal-offscreen or scrolled-ABOVE the fold = unreachable by a downward content scroll —
    // always cut (the walk discovers at page top, so nothing is above; a left/right-offscreen node
    // is never reached by vertical scroll).
    if (r.bottom <= 0 || r.right <= 0 || r.left >= vw) continue;
    // BELOW the current fold (deep-dive 3 §4.1 stage-2 un-blinding): a human reaches this only by
    // scrolling. Surface it into a SEPARATE `below_fold` pool, perception-gated + bounded reach, so
    // the reachability funnel can weigh an ad-AGNOSTIC content scroll to it (RULING 1/5). The
    // in-viewport pools are UNCHANGED — a caller that ignores `below_fold` behaves exactly as today
    // (degrade-safe). CONTENT-NAV affordances ONLY: ads/rewards are never surfaced below-fold (IVT —
    // an ad impression is the ad path's job, a reward is a gate), so the funnel can never originate an
    // ad click. Each box is tagged with its below-fold distance in viewport-heights.
    if (r.top >= vh) {
      if (out.below_fold.length >= 24) continue;          // a human reaches a few below-fold items, not 100
      const _bfVh = (r.top - vh) / (vh || 1);
      if (_bfVh > __REACH_MAX_VH__) continue;             // beyond human reach for a random click (reach cap)
      if (!_isPerceptible(el)) continue;
      const _bfText = (el.innerText || el.textContent || '').trim().slice(0, 80);
      const _bfHref = (el.getAttribute && el.getAttribute('href')) || '';
      const _bfC = classify(el, _bfText, _bfHref);
      if (_bfC.cls === 'ad' || _bfC.cls === 'reward' || _bfC.cls === 'other') continue;  // content-nav only
      const _bfKey = Math.round(r.x) + ',' + Math.round(r.y) + ',' + Math.round(r.width);
      if (seen.has(_bfKey)) continue;
      seen.add(_bfKey);
      const _bfBox = {x: r.x, y: r.y, width: r.width, height: r.height, text: _bfText, href: _bfHref,
                      kind: _bfC.cls, below_fold_vh: Math.round(_bfVh * 1000) / 1000};
      if (_bfC.cls === 'card') _bfBox.lane = _bfC.kind;
      out.below_fold.push(_bfBox);
      continue;
    }
    // Perception prefilter (deep-dive 3 §1 stage-1): a human cannot act on what they cannot
    // perceive OR cannot interact with. The ONE shared helper (_isPerceptible) replaces the old
    // inline opacity===0 check — it also catches EFFECTIVE (ancestor-chain) opacity below the
    // 0.05 glance floor and pointer-events:none, closing the gaps the rect-only + own-opacity
    // filter left. Backstopped at press time by hover-then-verify (the occlusion gate on the
    // fresh post-scroll rect), so this prefilter only has to be conservative.
    if (!_isPerceptible(el)) continue;
    const key = Math.round(r.x) + ',' + Math.round(r.y) + ',' + Math.round(r.width);
    if (seen.has(key)) continue;
    seen.add(key);
    const text = (el.innerText || el.textContent || '').trim().slice(0, 80);
    const href = (el.getAttribute && el.getAttribute('href')) || '';
    const c = classify(el, text, href);
    const box = {x: r.x, y: r.y, width: r.width, height: r.height, text: text, href: href};
    if (c.cls === 'reward') box.reward_kind = c.kind;
    if (c.cls === 'card') box.lane = c.kind;
    if (c.cls === 'ad') {
      box.ad_slot = c.kind;
      // Re-derive the explicit data-ad-slot in THIS scope (the `adslot` const in classify() is not
      // visible here). Referencing the classify-local `adslot` below threw an uncaught ReferenceError
      // on every engine (SpiderMonkey/JSC hard-throw; V8 too — line 630 is outside the try/catch),
      // which made the whole discovery IIFE throw and silently zeroed ALL affordances fleet-wide.
      const adslot = (el.getAttribute && el.getAttribute('data-ad-slot')) || '';
      // Infer the DISPLAY-FORMAT FAMILY from geometry/position so the per-format behavior model can
      // treat each format like a human does (host-agnostic: a fixed corner card = in-page push; a
      // fixed full-width bottom strip = sticky/anchor; a near-full-viewport overlay = interstitial;
      // a content-column rectangle not matching a known slot = native). The slot type (when present)
      // still wins; this only classifies the network's own self-mounted formats.
      try {
        const cs = getComputedStyle(el);
        const fixed = (cs.position === 'fixed' || cs.position === 'sticky');
        const wFrac = r.width / (vw || 1), hFrac = r.height / (vh || 1);
        const cls2 = ((el.className || '') + ' ' + (el.id || '')).toString().toLowerCase();
        if (!adslot) {
          if (/vignette/.test(cls2)) box.ad_format = 'vignette';
          else if (/in-?page|inpage|push|notif/.test(cls2)) box.ad_format = 'inpage_push';
          else if (fixed && wFrac >= 0.6 && hFrac >= 0.6) box.ad_format = 'interstitial';
          else if (fixed && r.bottom >= vh - 8 && wFrac >= 0.5 && r.height <= 140) box.ad_format = 'sticky';
          else if (fixed && r.width <= 420 && r.height <= 320) box.ad_format = 'inpage_push';
          else if (/sticky|anchor|social-?bar|footer-?ad|slider/.test(cls2)) box.ad_format = 'sticky';
          else if (/native|recommend|widget|content-?ad/.test(cls2)) box.ad_format = 'native';
        }
      } catch (e) {}
      // Resolve which ad NETWORK owns this surface from the page's generic ad-network data
      // attributes (no bespoke marker — any ad-supported site can expose these). Used ONLY to
      // gate the flag-off, per-network-certified accidental interaction. `filled` distinguishes a
      // rendered creative (an iframe/unit is present) from an empty/collapsed mount.
      const b = document.body;
      const slot = adslot || 'banner';
      box.network = ((b && (b.getAttribute('data-ads-network-' + slot) ||
                            b.getAttribute('data-ads-network'))) || '').toLowerCase();
      // FILLED means a REAL rendered creative — a descendant iframe/ins/img/rs-unit whose rendered
      // box has real height. An empty mount, or an injected-but-unfilled `data-rs-ad` div (height
      // 0, no creative served yet), is NOT filled → never eligible for an accidental click.
      const inner = el.querySelector && el.querySelector('iframe, ins, img, [data-rs-ad]');
      box.filled = !!(inner && inner.getBoundingClientRect &&
                      inner.getBoundingClientRect().height > 2);
      // Attribute the box to the SERVING network via its creative's CDN signature — authoritative
      // over the mount's declared data-ads-network attribute (the real filled creative is what a
      // human would actually click; the mount attr may name a different, unfilled demand source).
      // A cross-origin creative iframe/img matching a network CDN is, by definition, filled.
      const sigNet = _adNetFromCreative(el);
      if (sigNet) { box.network = sigNet; box.filled = true; }
      else if (!box.network && box.filled && _adPageNets.size === 1)
        box.network = Array.from(_adPageNets)[0];
    }
    out[c.cls].push(box);
    if (out.shuffle.length + out.card.length + out.category.length
        + out.reward.length + out.ad.length + out.home.length + out.other.length > 140) break;
  }
  // Secondary sweep — a FILLED cross-origin ad creative that self-injected OUTSIDE the site's ad
  // container (native / self-serving formats) is still a real, clickable in-page surface. Catch
  // ad-CDN iframes the container pass missed, host-agnostically via the CDN signature. This now
  // includes FULL-SCREEN overlays (vignette / interstitial) — the Monetag/Multitag-class formats
  // that self-inject a near-viewport iframe: they are what a real visitor sees + closes, so the
  // per-format behavior model must receive them (they were previously clamped out as "banner-shaped
  // only", which made every live overlay invisible → ad_formats_seen=[]). The popunder (a background
  // TAB, not an in-page element) is still handled only by the tab-close path.
  try {
    for (const ifr of Array.from(document.querySelectorAll('iframe[src]'))) {
      const net = _adNetFromUrl(ifr.getAttribute('src') || ifr.src || '');
      if (!net) continue;
      const r = ifr.getBoundingClientRect();
      if (r.width < 120 || r.height < 30) continue;                               // too small to be a real creative
      if (r.bottom <= 0 || r.right <= 0 || r.top >= vh || r.left >= vw) continue;  // in viewport
      const key = Math.round(r.x) + ',' + Math.round(r.y) + ',' + Math.round(r.width);
      if (seen.has(key)) continue;
      // Geometry-infer the format family for a self-injected creative. A fixed/sticky bottom bar is a
      // sticky; a small fixed corner card is an in-page-push; a fixed near-full-viewport overlay is a
      // VIGNETTE (grey-out + close/CTA); an otherwise near-full-page creative is an interstitial.
      // Falls back to banner. (Host-agnostic — geometry + position only.)
      let fmt = '';
      const wFrac = r.width / (vw || 1), hFrac = r.height / (vh || 1);
      try {
        const host = ifr.closest ? (ifr.closest('div,section,aside') || ifr) : ifr;
        const cs = getComputedStyle(host);
        const fixed = (cs.position === 'fixed' || cs.position === 'sticky');
        if (fixed && wFrac >= 0.6 && hFrac >= 0.6) fmt = 'vignette';
        else if (wFrac >= 0.85 && hFrac >= 0.85) fmt = 'interstitial';
        else if (fixed && r.bottom >= vh - 8 && wFrac >= 0.5 && r.height <= 140) fmt = 'sticky';
        else if (fixed && r.width <= 420 && r.height <= 320) fmt = 'inpage_push';
      } catch (e) {}
      // A tall creative that is NOT a recognized full-screen overlay shape is skipped (old clamp) —
      // it is not a plain banner and not a classified overlay, so we do not guess.
      if (r.height > 340 && !fmt) continue;
      seen.add(key);
      const b = {x: r.x, y: r.y, width: r.width, height: r.height, text: '', href: '',
                 ad_slot: 'banner', network: net, filled: true};
      if (fmt) b.ad_format = fmt;
      out.ad.push(b);
    }
  } catch (e) {}
  // Tertiary sweep — a self-INJECTED fixed, very-high-z-index overlay whose creative src is OPAQUE
  // (about:blank / srcdoc written by the network's service worker), which the CDN-signature passes
  // above cannot match on a URL. Population-shaped: every push / vignette / in-page-push network
  // mounts a fixed max-z overlay (an iframe, or a wrapper containing one) appended near <body>. We
  // require it to actually CONTAIN a creative (iframe/ins) so a site's own cookie/consent modal (a
  // plain div, no creative) is never misread as an ad, and we attribute it to a child creative's CDN
  // signature or — failing that — the SOLE ad-loader network on the page (never a site host).
  try {
    // Scan ALL body descendants (not just direct children): networks like Adsterra mount their
    // vignette/social-bar overlay NESTED (body > div > … > iframe), so a `body > *` scan missed
    // them entirely — the raw-DOM census (which scans `body *`) saw 34 such overlays while this
    // pass saw 0. Bounded so it never sweeps the whole DOM: stop after a couple of real overlays
    // (a human faces 1–2 blockers, not 20) or a hard examine cap. Every ad-specific gate below
    // (fixed/absolute + z>=1000 + contains-creative + net-attributed) still holds, so a site's own
    // cookie/consent modal (a plain div, no creative, or no ad-net) is never misread as an ad.
    let _ovAdded = 0, _ovSeen = 0;
    const overlays = Array.from(document.querySelectorAll('body *'));
    for (const el of overlays) {
      if (_ovAdded >= 3 || _ovSeen >= 4000) break;
      _ovSeen++;
      let cs; try { cs = getComputedStyle(el); } catch (e) { continue; }
      if (!cs || (cs.position !== 'fixed' && cs.position !== 'absolute')) continue;
      const z = parseInt(cs.zIndex || '0', 10) || 0;
      if (z < 1000) continue;                                                      // real ad overlays ride very high z
      const r = el.getBoundingClientRect();
      if (r.width < 100 || r.height < 60) continue;
      if (r.bottom <= 0 || r.right <= 0 || r.top >= vh || r.left >= vw) continue;  // in viewport
      const wFrac = r.width / (vw || 1), hFrac = r.height / (vh || 1);
      const nearFull = (wFrac >= 0.6 && hFrac >= 0.6);
      // hasCreative: the overlay IS or CONTAINS an ad creative. Broadened beyond iframe/ins to
      // img + canvas because Adsterra renders its vignette / social-bar as a styled <div> holding an
      // <img> (or canvas), NOT an iframe — the iframe/ins-only gate skipped every DIV vignette (the
      // raw census saw 33 such overlays, this pass saw 0). A NEAR-FULL fixed high-z overlay needs no
      // detectable child creative at all: on a page whose SOLE ad loader is Adsterra it is
      // unambiguously the vignette (a real consent modal is a small bottom strip, never near-full),
      // so geometry + sole-net attribution suffices — exactly what the raw census matches on.
      const hasCreative = (el.tagName === 'IFRAME')
        || (el.querySelector && !!el.querySelector('iframe, ins, img, canvas'));
      if (!hasCreative && !nearFull) continue;                                     // small overlay, no creative → not an ad
      const key = Math.round(r.x) + ',' + Math.round(r.y) + ',' + Math.round(r.width);
      if (seen.has(key)) continue;
      let net = _adNetFromCreative(el);
      if (!net && _adPageNets.size === 1) net = Array.from(_adPageNets)[0];
      if (!net) continue;                                                          // never attribute a non-ad overlay
      seen.add(key);
      let fmt;
      if (nearFull) fmt = (cs.position === 'fixed') ? 'vignette' : 'interstitial';
      else if (r.bottom >= vh - 8 && wFrac >= 0.5 && r.height <= 140) fmt = 'sticky';
      else fmt = 'inpage_push';
      out.ad.push({x: r.x, y: r.y, width: r.width, height: r.height, text: '', href: '',
                   ad_slot: 'banner', network: net, filled: true, ad_format: fmt, injected: true});
      _ovAdded++;
    }
  } catch (e) {}
  // Parse a generic "X of N shuffles/left/remaining" budget indicator from the page text.
  try {
    const bodyText = (document.body && document.body.innerText || '').slice(0, 20000);
    let m = bodyText.match(/(\d+)\s*(?:of|\/)\s*(\d+)\s*(?:shuffles?|left|remaining|credits?)/i);
    if (m) { out.budget.remaining = parseInt(m[1], 10); out.budget.total = parseInt(m[2], 10); }
    else {
      m = bodyText.match(/(\d+)\s*(?:shuffles?|credits?)\s*(?:left|remaining)/i);
      if (m) out.budget.remaining = parseInt(m[1], 10);
    }
  } catch (e) {}
  // RF_GATES muted: the soul is GATELESS — drop every reward surface and the shuffle budget so
  // no downstream step (reshuffle refill, unlock watch) can act on a gate that does not exist.
  if (!out.gates_enabled) {
    out.reward = [];
    out.budget = {remaining: null, total: null};
  }
  return out;
})()
"""


def build_discover_js(ad_cdn_sigs: "Sequence[tuple[str, str]] | None" = None) -> str:
    """Return the discovery JS with the ad-CDN signature table injected as a JSON literal.

    ``ad_cdn_sigs`` is a sequence of ``(network, pattern)`` pairs; the JS rebuilds ``RegExp``
    objects from the pattern strings to classify ``ad`` affordances by creative host. Omit it (or
    pass ``None``) for the generic form (empty table) used by plain navigation callers.
    """
    return DISCOVER_JS_TEMPLATE.replace(
        "__IS_PERCEPTIBLE_FN__", IS_PERCEPTIBLE_FN_JS,
    ).replace(
        "__REACH_MAX_VH__", repr(float(REACH_MAX_VH)),
    ).replace(
        "__AD_CDN_SIGS_JSON__", json.dumps([[n, p] for n, p in (ad_cdn_sigs or [])]))


# The generic, ad-agnostic discovery JS (empty ad-CDN table) — for callers that only navigate.
DISCOVER_JS = build_discover_js()
